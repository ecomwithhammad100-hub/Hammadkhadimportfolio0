import type { Metadata } from "next";
import { Anton, Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const anton = Anton({
  variable: "--font-display",
  subsets: ["latin"],
  weight: "400",
  display: "swap",
});

const inter = Inter({
  variable: "--font-body",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-accent",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Hammad Khadim | Web Designer & Shopify Expert",
  description:
    "Hammad Khadim — Professional Web Designer, UI/UX Designer, and Shopify Expert. Creating exceptional digital experiences through modern web design, creative UI/UX, and powerful website development.",
  keywords: [
    "Hammad Khadim",
    "Web Designer",
    "Shopify Expert",
    "UI UX Designer",
    "Shopify Developer",
    "Web Design",
    "Landing Page Design",
    "Custom Website Development",
    "Portfolio",
  ],
  authors: [{ name: "Hammad Khadim" }],
  creator: "Hammad Khadim",
  icons: {
    icon: [
      { url: "/favicon.png", sizes: "256x256", type: "image/png" },
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16.png", sizes: "16x16", type: "image/png" },
    ],
    shortcut: "/favicon.png",
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    title: "Hammad Khadim | Web Designer & Shopify Expert",
    description:
      "Creating exceptional digital experiences through modern web design, creative UI/UX, and powerful website development.",
    siteName: "Hammad Khadim",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Hammad Khadim — Web Designer & Shopify Expert",
    description:
      "Creating exceptional digital experiences through modern web design, creative UI/UX, and powerful website development.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${anton.variable} ${inter.variable} ${spaceGrotesk.variable} antialiased bg-background text-foreground overflow-x-hidden`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
