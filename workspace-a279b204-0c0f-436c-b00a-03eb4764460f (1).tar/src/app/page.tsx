import { CursorGlow } from "@/components/portfolio/cursor-glow";
import { ScrollProgress } from "@/components/portfolio/scroll-progress";
import { Navbar } from "@/components/portfolio/navbar";
import { Hero } from "@/components/portfolio/hero";
import { About } from "@/components/portfolio/about";
import { Skills } from "@/components/portfolio/skills";
import { Services } from "@/components/portfolio/services";
import { Projects } from "@/components/portfolio/projects";
import { Stats } from "@/components/portfolio/stats";
import { Contact } from "@/components/portfolio/contact";
import { Footer } from "@/components/portfolio/footer";

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col">
      <CursorGlow />
      <ScrollProgress />
      <Navbar />

      <main className="flex-1">
        <Hero />
        <About />
        <Skills />
        <Services />
        <Projects />
        <Stats />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
