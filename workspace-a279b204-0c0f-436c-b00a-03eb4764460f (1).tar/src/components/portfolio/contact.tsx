"use client";

import { type ReactNode } from "react";
import { motion } from "framer-motion";
import {
  ArrowUpRight,
  Github,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Send,
  Sparkles,
} from "lucide-react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { AnimatedText } from "./animated-text";
import { Magnetic } from "./magnetic";
import { Reveal } from "./reveal";
import { WhatsAppLogo } from "./whatsapp-logo";

// Editable contact details — replace with real values anytime.
const CONTACT = {
  whatsappNumber: "923026049586", // intl format, no + (03026049586)
  whatsappDisplay: "+92 302 6049586",
  whatsappMessage: "Hi Hammad, I'd like to discuss a project.",
  email: "Contactwithhammadkhadim@gmail.com",
  location: "Pakistan",
};

const SOCIALS = [
  { label: "Instagram", icon: Instagram, href: "https://instagram.com/" },
  { label: "LinkedIn", icon: Linkedin, href: "https://linkedin.com/" },
  { label: "GitHub", icon: Github, href: "https://github.com/" },
];

export function Contact() {
  const reduced = useReducedMotion();

  const waLink = `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(CONTACT.whatsappMessage)}`;
  const mailLink = `mailto:${CONTACT.email}?subject=${encodeURIComponent("Project Inquiry — Hammad Khadim")}`;

  const scrollTo = (href: string) =>
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/2 h-[60vh] w-[80vh] -translate-x-1/2 -translate-y-1/2 rounded-full bg-teal-700/15 blur-[160px]" />
      </div>
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid bg-grid-fade opacity-20" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-[2.5rem] gradient-border p-8 sm:p-12 lg:p-16">
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-teal-500/20 blur-3xl"
            animate={reduced ? {} : { scale: [1, 1.15, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />

          <div className="relative grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-16">
            {/* LEFT */}
            <div className="flex flex-col gap-6">
              <Reveal>
                <div className="flex items-center gap-3">
                  <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">06</span>
                  <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
                  <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                    Contact
                  </span>
                </div>
              </Reveal>

              <AnimatedText
                text="LET'S CREATE SOMETHING EXTRAORDINARY."
                as="h2"
                split="word"
                className="font-display text-4xl uppercase leading-[0.92] text-white sm:text-5xl md:text-6xl"
              />

              <Reveal delay={0.15}>
                <p className="max-w-md text-base text-muted-foreground sm:text-lg">
                  Have a project in mind or need a professional website? Let&apos;s
                  discuss your next build and create something memorable.
                </p>
              </Reveal>

              {/* availability */}
              <Reveal delay={0.25}>
                <div className="inline-flex w-fit items-center gap-2 rounded-full glass px-4 py-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal-400 opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-teal-400" />
                  </span>
                  <span className="font-accent text-xs uppercase tracking-[0.25em] text-teal-200/90">
                    Available for new projects
                  </span>
                </div>
              </Reveal>

              {/* CTAs */}
              <div className="mt-2 flex flex-col gap-4 sm:flex-row sm:flex-wrap">
                <Magnetic as="div" strength={0.3}>
                  <a
                    href={waLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-glow group flex items-center gap-2 rounded-full px-7 py-3.5 font-accent text-sm uppercase tracking-wider"
                  >
                    <WhatsAppLogo size={16} />
                    WhatsApp
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                </Magnetic>

                <Magnetic as="div" strength={0.25}>
                  <a
                    href={mailLink}
                    className="btn-ghost-glow flex items-center gap-2 rounded-full px-7 py-3.5 font-accent text-sm uppercase tracking-wider"
                  >
                    <Mail className="h-4 w-4" />
                    Email Me
                  </a>
                </Magnetic>

                <Magnetic as="div" strength={0.25}>
                  <button
                    onClick={() => scrollTo("#projects")}
                    className="btn-ghost-glow flex items-center gap-2 rounded-full px-7 py-3.5 font-accent text-sm uppercase tracking-wider"
                  >
                    <Sparkles className="h-4 w-4" />
                    View My Work
                  </button>
                </Magnetic>
              </div>

              {/* socials */}
              <Reveal delay={0.35}>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  {SOCIALS.map((s) => (
                    <a
                      key={s.label}
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.label}
                      className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-muted-foreground transition-all duration-300 hover:border-teal-300/60 hover:text-teal-300 hover:shadow-[0_0_20px_rgba(45,212,191,0.4)]"
                    >
                      <s.icon className="h-5 w-5" />
                    </a>
                  ))}
                </div>
              </Reveal>
            </div>

            {/* RIGHT — inquiry / details panel */}
            <Reveal delay={0.2}>
              <div className="flex h-full flex-col gap-4 rounded-3xl glass-strong p-6 sm:p-8">
                <div className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/70">
                  Project Inquiry
                </div>

                <div className="flex flex-col gap-5">
                  <ContactRow icon={<WhatsAppLogo size={20} />} label="WhatsApp" value={CONTACT.whatsappDisplay} href={waLink} />
                  <ContactRow icon={<Mail className="h-5 w-5" />} label="Email" value={CONTACT.email} href={mailLink} />
                  <ContactRow icon={<MapPin className="h-5 w-5" />} label="Location" value={CONTACT.location} />
                </div>

                <div className="my-2 h-px w-full bg-gradient-to-r from-transparent via-teal-400/20 to-transparent" />

                <div className="flex flex-col gap-3">
                  <div className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/70">
                    Response Time
                  </div>
                  <div className="flex items-center gap-3">
                    <Send className="h-4 w-4 text-teal-300" />
                    <span className="text-sm text-muted-foreground">
                      Usually replies within a few hours.
                    </span>
                  </div>
                </div>

                <div className="mt-auto rounded-2xl border border-teal-400/20 bg-teal-500/5 p-4">
                  <p className="text-sm text-teal-100/80">
                    Whether it&apos;s a Shopify store, a business website, or a
                    custom landing page — tell me about your idea and I&apos;ll
                    help you bring it to life.
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactRow({
  icon,
  label,
  value,
  href,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  const content = (
    <div className="group flex items-center gap-4">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-teal-400/25 bg-teal-500/10 text-teal-300 transition-all duration-300 group-hover:scale-105 group-hover:border-teal-300/60">
        {icon}
      </div>
      <div className="flex flex-col">
        <span className="font-accent text-[0.6rem] uppercase tracking-[0.25em] text-muted-foreground">
          {label}
        </span>
        <span className="text-base text-white transition-colors duration-300 group-hover:text-teal-200">
          {value}
        </span>
      </div>
      {href && (
        <ArrowUpRight className="ml-auto h-4 w-4 text-muted-foreground opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100 group-hover:text-teal-300" />
      )}
    </div>
  );

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className="block">
        {content}
      </a>
    );
  }
  return content;
}
