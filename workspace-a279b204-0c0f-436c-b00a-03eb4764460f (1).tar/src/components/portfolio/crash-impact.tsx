"use client";

import { motion } from "framer-motion";
import { useMemo } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

type CrashImpactProps = {
  /** seconds after mount when the crash impact fires */
  impactAt: number;
  /** accent color for the energy/flash */
  accent?: string;
};

// pre-computed burst particles (angle in deg, distance in px, size, delay)
const BURST = Array.from({ length: 34 }, (_, i) => {
  const angle = (i / 34) * 360 + ((i * 37) % 12);
  const dist = 120 + ((i * 53) % 200);
  const size = 5 + ((i * 13) % 6);
  const delay = (i % 6) * 0.015;
  return {
    x: Math.cos((angle * Math.PI) / 180) * dist,
    y: Math.sin((angle * Math.PI) / 180) * dist,
    size,
    delay,
  };
});

/**
 * Cinematic crash-impact overlay: fires a bright shockwave, screen flash,
 * emerald particle burst, and energy bursts at `impactAt`.
 * Bold and powerful. Rendered once, plays once. Disabled on reduced-motion.
 */
export function CrashImpact({ impactAt, accent = "#2ee6c8" }: CrashImpactProps) {
  const reduced = useReducedMotion();
  const flash = useMemo(
    () => `radial-gradient(circle at 50% 45%, #ffffff, ${accent} 20%, ${accent}88 38%, transparent 62%)`,
    [accent],
  );
  const disc = useMemo(
    () => `radial-gradient(circle, ${accent}cc 0%, ${accent}66 30%, transparent 70%)`,
    [accent],
  );

  if (reduced) return null;

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 z-50 overflow-hidden">
      {/* ===== IMPACT FLASH (bright, brief) ===== */}
      <motion.div
        className="absolute inset-0"
        style={{ background: flash, mixBlendMode: "screen" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.9, 0.35, 0] }}
        transition={{ duration: 0.85, times: [0, 0.1, 0.35, 1], delay: impactAt }}
      />

      {/* ===== BRIGHT EXPANDING GLOW DISC (filled, very visible) ===== */}
      <motion.div
        className="absolute left-1/2 top-[45%] h-56 w-56 rounded-full"
        style={{ x: "-50%", y: "-50%", background: disc, filter: "blur(4px)" }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 2.5, 5], opacity: [0, 0.95, 0] }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: impactAt }}
      />

      {/* ===== SHOCKWAVE RINGS (thick, bright, expanding) ===== */}
      <motion.div
        className="absolute left-1/2 top-[45%] h-24 w-24 rounded-full border-4"
        style={{
          x: "-50%",
          y: "-50%",
          borderColor: accent,
          boxShadow: `0 0 50px ${accent}, 0 0 100px ${accent}aa, inset 0 0 30px ${accent}88`,
        }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 4, 8], opacity: [0, 1, 0] }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: impactAt }}
      />
      <motion.div
        className="absolute left-1/2 top-[45%] h-24 w-24 rounded-full border-[3px]"
        style={{ x: "-50%", y: "-50%", borderColor: `${accent}cc`, boxShadow: `0 0 40px ${accent}88` }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 6, 11], opacity: [0, 0.85, 0] }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: impactAt + 0.08 }}
      />
      <motion.div
        className="absolute left-1/2 top-[45%] h-24 w-24 rounded-full border-2"
        style={{ x: "-50%", y: "-50%", borderColor: `${accent}88` }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 9, 15], opacity: [0, 0.6, 0] }}
        transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: impactAt + 0.16 }}
      />

      {/* ===== PARTICLE BURST (large, bright) ===== */}
      {BURST.map((p, i) => (
        <motion.span
          key={i}
          className="absolute left-1/2 top-[45%] rounded-full"
          style={{
            width: p.size,
            height: p.size,
            background: "#ffffff",
            boxShadow: `0 0 14px ${accent}, 0 0 24px ${accent}, 0 0 8px #ffffff`,
            x: "-50%",
            y: "-50%",
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            x: ["-50%", `calc(-50% + ${p.x}px)`],
            y: ["-50%", `calc(-50% + ${p.y}px)`],
            opacity: [0, 1, 0],
            scale: [0, 1.4, 0.2],
          }}
          transition={{
            duration: 1.1,
            ease: [0.22, 1, 0.36, 1],
            delay: impactAt + p.delay,
          }}
        />
      ))}

      {/* ===== ENERGY BURSTS ===== */}
      <motion.div
        className="absolute left-1/2 top-[45%] h-56 w-56 rounded-full"
        style={{ x: "-50%", y: "-50%", background: `radial-gradient(circle, ${accent}aa, transparent 60%)`, filter: "blur(16px)" }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 2, 3.2], opacity: [0, 0.8, 0] }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: impactAt }}
      />
    </div>
  );
}
