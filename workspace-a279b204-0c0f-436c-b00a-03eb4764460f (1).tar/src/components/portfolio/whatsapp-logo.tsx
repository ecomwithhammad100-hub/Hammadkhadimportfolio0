import { cn } from "@/lib/utils";

type Props = {
  className?: string;
  size?: number;
  /** monochrome override — renders in currentColor */
  mono?: boolean;
};

/**
 * Official WhatsApp logo (green speech bubble with white phone handset).
 * Brand color #25D366. Pass `mono` to render in currentColor.
 */
export function WhatsAppLogo({ className, size = 24, mono = false }: Props) {
  const circle = mono ? "currentColor" : "#25D366";
  const phone = mono ? "var(--bg, #050807)" : "#FFFFFF";
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={cn("inline-block", className)}
      aria-label="WhatsApp"
      role="img"
    >
      {/* green speech-bubble circle */}
      <path
        fill={circle}
        d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2z"
      />
      {/* white phone handset */}
      <path
        fill={phone}
        d="M17.1 14.92c-.24-.12-1.43-.71-1.65-.79-.22-.07-.38-.12-.54.12-.16.24-.62.79-.76.95-.14.16-.28.18-.52.06-.24-.12-1.02-.38-1.94-1.2-.72-.64-1.2-1.43-1.34-1.67-.14-.24-.01-.37.11-.49.11-.11.24-.28.37-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.4-.4-.54-.41h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.32.98 2.48.12.16 1.69 2.58 4.1 3.62.57.25 1.02.4 1.37.51.58.18 1.1.16 1.52.1.46-.07 1.43-.58 1.63-1.15.2-.57.2-1.05.14-1.15-.06-.1-.22-.16-.46-.28z"
      />
    </svg>
  );
}
