"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const LINKS = [
  { label: "Home", href: "#home", id: "home" },
  { label: "About", href: "#about", id: "about" },
  { label: "Skills", href: "#skills", id: "skills" },
  { label: "Services", href: "#services", id: "services" },
  { label: "Projects", href: "#projects", id: "projects" },
  { label: "Contact", href: "#contact", id: "contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 },
    );
    LINKS.forEach((l) => {
      const el = document.getElementById(l.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const go = (href: string) => {
    setOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
        className="fixed inset-x-0 top-0 z-[80] flex justify-center px-4 pt-4"
      >
        <nav
          className={cn(
            "flex w-full max-w-6xl items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 sm:px-6",
            scrolled
              ? "glass-strong py-2 shadow-[0_8px_40px_rgba(0,0,0,0.5)]"
              : "border border-transparent bg-transparent",
          )}
        >
          {/* text-based name treatment — no logo */}
          <button
            onClick={() => go("#home")}
            className="group flex flex-col leading-none"
            aria-label="Hammad Khadim — home"
          >
            <span className="font-display text-base uppercase tracking-[0.2em] text-white sm:text-lg">
              Hammad <span className="brand-teal text-glow-teal">Khadim</span>
            </span>
            <span className="font-accent text-[0.5rem] uppercase tracking-[0.4em] text-teal-300/50">
              Web Designer
            </span>
          </button>

          {/* desktop links */}
          <ul className="hidden items-center gap-1 md:flex">
            {LINKS.map((link) => {
              const isActive = active === link.id;
              return (
                <li key={link.id}>
                  <button
                    onClick={() => go(link.href)}
                    className={cn(
                      "relative rounded-full px-4 py-2 font-accent text-sm transition-colors duration-300",
                      isActive
                        ? "text-teal-200"
                        : "text-muted-foreground hover:text-white",
                    )}
                  >
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-active"
                        className="absolute inset-0 -z-10 rounded-full border border-teal-400/30 bg-teal-500/10"
                        transition={{ type: "spring", stiffness: 300, damping: 26 }}
                      />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>

          {/* CTA + mobile toggle */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => go("#contact")}
              className="hidden rounded-full border border-teal-400/40 px-5 py-2 font-accent text-sm text-teal-200 transition-all duration-300 hover:border-teal-300 hover:bg-teal-500/10 hover:shadow-[0_0_20px_rgba(45,212,191,0.4)] sm:block"
            >
              Contact Me
            </button>
            <button
              onClick={() => setOpen((v) => !v)}
              className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-white md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </nav>
      </motion.header>

      {/* mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[75] md:hidden"
          >
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute inset-x-4 top-24 overflow-hidden rounded-2xl glass-strong p-2"
            >
              <ul className="flex flex-col">
                {LINKS.map((link, i) => (
                  <motion.li
                    key={link.id}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i }}
                  >
                    <button
                      onClick={() => go(link.href)}
                      className={cn(
                        "flex w-full items-center justify-between rounded-xl px-4 py-3 font-accent text-base transition-colors",
                        active === link.id
                          ? "bg-teal-500/10 text-teal-200"
                          : "text-muted-foreground hover:bg-white/5 hover:text-white",
                      )}
                    >
                      <span>{link.label}</span>
                      <span className="font-mono text-xs text-teal-400/50">0{i + 1}</span>
                    </button>
                  </motion.li>
                ))}
                <li className="p-2">
                  <button
                    onClick={() => go("#contact")}
                    className="btn-glow w-full rounded-xl px-4 py-3 font-accent text-sm uppercase tracking-wider"
                  >
                    Contact Me
                  </button>
                </li>
              </ul>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
