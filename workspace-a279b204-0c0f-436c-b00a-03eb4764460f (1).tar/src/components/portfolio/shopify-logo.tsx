import { cn } from "@/lib/utils";

type Props = {
  className?: string;
  /** pixel size of the mark (height) */
  size?: number;
  /** monochrome override — when set, renders a single-color mark (uses currentColor) */
  mono?: boolean;
};

/**
 * Official Shopify bag mark (the shopping bag with the white "S").
 * Multi-color by default (Shopify green #95BF47 / #5E8E3E / white S).
 * Pass `mono` to render in currentColor (for themed contexts).
 */
export function ShopifyMark({ className, size = 24, mono = false }: Props) {
  if (mono) {
    return (
      <svg
        viewBox="0 0 18 21"
        width={size}
        height={size * (21 / 18)}
        className={cn("inline-block", className)}
        aria-label="Shopify"
        role="img"
      >
        <path
          fill="currentColor"
          d="M14.898 4.027c-.014-.099-.1-.153-.173-.153-.073 0-1.502-.029-1.502-.029s-1.183-1.146-1.31-1.272c-.117-.117-.346-.082-.435-.055 0 0-.224.069-.583.183-.058-.193-.143-.423-.252-.651-.368-.721-.91-1.103-1.538-1.103-.043 0-.087.002-.13.006-.018-.024-.036-.047-.055-.07-.276-.331-.628-.495-1.043-.477-.81.031-1.619.619-2.276 1.654-.462.729-.81 1.644-.91 2.484l-1.875.582c-.548.172-.565.189-.634.708-.049.378-1.493 11.504-1.493 11.504l11.504 2.052 4.952-1.238c0-.001-1.493-12.086-1.507-12.185z"
        />
      </svg>
    );
  }
  return (
    <svg
      viewBox="0 0 18 21"
      width={size}
      height={size * (21 / 18)}
      className={cn("inline-block", className)}
      aria-label="Shopify"
      role="img"
    >
      {/* front of bag */}
      <path
        fill="#95BF47"
        d="M14.898 4.027c-.014-.099-.1-.153-.173-.153-.073 0-1.502-.029-1.502-.029s-1.183-1.146-1.31-1.272c-.117-.117-.346-.082-.435-.055 0 0-.224.069-.583.183-.058-.193-.143-.423-.252-.651-.368-.721-.91-1.103-1.538-1.103-.043 0-.087.002-.13.006-.018-.024-.036-.047-.055-.07-.276-.331-.628-.495-1.043-.477-.81.031-1.619.619-2.276 1.654-.462.729-.81 1.644-.91 2.484l-1.875.582c-.548.172-.565.189-.634.708-.049.378-1.493 11.504-1.493 11.504l11.504 2.052 4.952-1.238c0-.001-1.493-12.086-1.507-12.185z"
      />
      {/* darker side of bag */}
      <path
        fill="#5E8E3E"
        d="M14.725 3.874c-.073 0-1.502-.029-1.502-.029s-1.183-1.146-1.31-1.272c-.049-.049-.115-.073-.183-.073l-1.042 21.428 4.952-1.238c0-.001-1.493-12.086-1.507-12.185-.014-.099-.1-.153-.173-.153-.073 0-.207.001-.207.001z"
      />
      {/* white S */}
      <path
        fill="#FFFFFF"
        d="M11.629 7.221l-.583 2.183s-.651-.292-1.431-.292c-1.155 0-1.619.576-1.619 1.146 0 .674.612.971 1.539 1.431 1.493.731 2.183 1.576 2.183 2.831 0 1.954-1.539 3.142-3.631 3.142-1.619 0-2.831-.612-2.831-.612l.476-2.054s1.042.612 1.954.612c.612 0 1.042-.292 1.042-.811 0-.476-.388-.731-1.183-1.146-1.042-.549-2.044-1.155-2.044-2.484 0-1.954 1.576-3.245 3.795-3.245 1.273 0 2.183.549 2.183.549z"
      />
    </svg>
  );
}

type FullProps = Props & {
  /** show the "shopify" wordmark next to the mark */
  withWordmark?: boolean;
  /** wordmark size relative to mark */
  wordmarkClassName?: string;
};

/**
 * Full Shopify logo: bag mark + optional "shopify" wordmark.
 * Use `withWordmark` to replace the written word "Shopify" with the official lockup.
 */
export function ShopifyLogo({
  className,
  size = 24,
  mono = false,
  withWordmark = false,
  wordmarkClassName,
}: FullProps) {
  if (!withWordmark) {
    return <ShopifyMark className={className} size={size} mono={mono} />;
  }
  return (
    <span className={cn("inline-flex items-center gap-1.5 align-middle", className)}>
      <ShopifyMark size={size} mono={mono} />
      <span
        className={cn(
          "font-semibold lowercase tracking-tight",
          mono ? "text-current" : "text-[#95BF47]",
          wordmarkClassName,
        )}
        style={{ fontSize: size * 0.82 }}
      >
        shopify
      </span>
    </span>
  );
}
