"use client";

import { motion, type Variants } from "framer-motion";
import { useMemo } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { cn } from "@/lib/utils";

type AnimatedTextProps = {
  text: string;
  className?: string;
  /** split mode: per-word or per-character */
  split?: "word" | "char";
  /** delay before the animation starts (seconds) */
  delay?: number;
  /** stagger between items (seconds) */
  stagger?: number;
  /** y offset for the reveal (px) */
  y?: number;
  /** render as this element */
  as?: "h1" | "h2" | "h3" | "h4" | "p" | "span" | "div";
  once?: boolean;
};

/**
 * Splits text into words / characters and reveals them with a staggered
 * mask-up animation. Respects prefers-reduced-motion (renders static text).
 */
export function AnimatedText({
  text,
  className,
  split = "word",
  delay = 0,
  stagger = 0.04,
  y = 28,
  as = "div",
  once = true,
}: AnimatedTextProps) {
  const reduced = useReducedMotion();
  const Tag = motion[as] as typeof motion.div;

  const items = useMemo(() => {
    if (split === "char") return text.split("");
    return text.split(" ");
  }, [text, split]);

  const container: Variants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: reduced ? 0 : stagger,
        delayChildren: delay,
      },
    },
  };

  const child: Variants = {
    hidden: reduced ? {} : { y, opacity: 0, filter: "blur(6px)" },
    visible: {
      y: 0,
      opacity: 1,
      filter: "blur(0px)",
      transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
    },
  };

  return (
    <Tag
      className={cn("inline-block", className)}
      variants={container}
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin: "-10% 0px" }}
      aria-label={text}
    >
      {items.map((item, i) => (
        <span
          key={`${item}-${i}`}
          className="inline-block overflow-hidden align-bottom"
          aria-hidden
        >
          <motion.span
            className="inline-block"
            variants={child}
            style={{ willChange: "transform, opacity" }}
          >
            {item}
            {split === "word" && i < items.length - 1 ? "\u00A0" : ""}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}
