"use client";

import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowUpRight, Briefcase, Rocket, Sparkles, Zap } from "lucide-react";
import { useEffect } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { Magnetic } from "./magnetic";
import { WaterfallName } from "./waterfall-name";
import { AnimatedPortrait } from "./animated-portrait";
import { CrashImpact } from "./crash-impact";
import { ShopifyLogo, ShopifyMark } from "./shopify-logo";

const ROTATING_TITLES = [
  "Web Designer & Shopify Expert",
  "UI/UX Designer",
  "Creative Frontend Developer",
];

const STATS = [
  { icon: <Briefcase className="h-4 w-4" />, value: "8–10", label: "Local Projects" },
  { icon: <ShopifyMark size={16} />, value: "Shopify & Web", label: "Development" },
  { icon: <Rocket className="h-4 w-4" />, value: "Business", label: "Digital Solutions" },
  { icon: <Zap className="h-4 w-4" />, value: "Always Ready", label: "For New Projects" },
];

export function Hero() {
  const reduced = useReducedMotion();

  // mouse parallax (for PORTFOLIO bg text)
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const px = useSpring(mx, { stiffness: 60, damping: 18 });
  const bgTextX = useTransform(px, [-0.5, 0.5], [-30, 30]);
  void my;

  useEffect(() => {
    if (reduced) return;
    const move = (e: MouseEvent) => {
      mx.set(e.clientX / window.innerWidth - 0.5);
      my.set(e.clientY / window.innerHeight - 0.5);
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, [mx, my, reduced]);

  const scrollTo = (href: string) =>
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth", block: "start" });

  // ===== CRASH-INTRO TIMING =====
  const baseDelay = 0.25;
  const stagger = 0.05;
  const hammadLen = 6;
  const khadimDelay = baseDelay + hammadLen * stagger + 0.04; // 0.59
  // moment the full name crashes into place (last letter lands + spring settle)
  const crashImpactAt = khadimDelay + 5 * stagger + 0.13; // ~0.97s

  // post-crash reveal timings
  const swooshDelay = crashImpactAt + 0.08;
  const titleDelay = crashImpactAt + 0.22;
  const descDelay = crashImpactAt + 0.36;
  const ctaDelay = crashImpactAt + 0.5;

  // screen-shake keyframes (fires once at impact)
  const shake = reduced
    ? {}
    : {
        x: [0, -11, 11, -8, 8, -5, 5, -2, 0],
        y: [0, 6, -6, 4, -4, 2, -2, 1, 0],
      };

  return (
    <section
      id="home"
      className="relative flex min-h-screen flex-col overflow-hidden pt-28 pb-6"
    >
      {/* ===== AMBIENT BACKGROUND ===== */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-32 top-0 h-[55vh] w-[55vh] rounded-full bg-emerald-600/20 blur-[130px] animate-drift" />
        <div className="absolute right-[-10%] top-1/4 h-[65vh] w-[65vh] rounded-full bg-teal-500/15 blur-[150px] animate-drift" style={{ animationDelay: "4s" }} />
        <div className="absolute bottom-0 left-1/3 h-[40vh] w-[40vh] rounded-full bg-cyan-700/10 blur-[120px] animate-drift" style={{ animationDelay: "8s" }} />
      </div>

      {/* grid + dot matrix */}
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid bg-grid-fade opacity-30" />
      <div className="dot-matrix pointer-events-none absolute bottom-[14%] left-[8%] -z-10 h-32 w-40 opacity-30 mask-fade-b" />

      {/* diagonal light streaks */}
      <div className="light-streak top-[12%] left-[-10%] w-[60%] rotate-[18deg] opacity-60" />
      <div className="light-streak bottom-[18%] left-[-5%] w-[50%] rotate-[18deg] opacity-50" />
      <div className="light-streak top-[40%] right-[-10%] w-[55%] -rotate-[18deg] opacity-40" />

      {/* ===== GIANT METALLIC PORTFOLIO TEXT ===== */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-[40%] -z-10 select-none text-center"
        style={{ x: bgTextX }}
      >
        <motion.span
          className="font-display block whitespace-nowrap text-[17vw] leading-none"
          style={{ WebkitTextStroke: "1px rgba(255,255,255,0.06)", color: "transparent" }}
          initial={reduced ? {} : { opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        >
          PORTFOLIO
        </motion.span>
      </motion.div>

      {/* ===== CRASH IMPACT OVERLAY (shockwave + flash + particle burst) ===== */}
      <CrashImpact impactAt={crashImpactAt} accent="#2ee6c8" />

      {/* ===== SHAKE WRAPPER (screen shake at impact) ===== */}
      <motion.div
        className="flex flex-1 flex-col"
        animate={shake}
        transition={reduced ? {} : { duration: 0.55, delay: crashImpactAt, ease: "easeOut" }}
      >
        {/* ===== MAIN GRID ===== */}
        <div className="mx-auto grid w-full max-w-7xl flex-1 grid-cols-1 items-center gap-6 px-4 sm:px-6 lg:grid-cols-12 lg:gap-4">
          {/* LEFT — text */}
          <div className="order-2 lg:order-1 lg:col-span-7">
            {/* badge */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-5 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5"
            >
              <Sparkles className="h-3.5 w-3.5 text-teal-300" />
              <span className="font-accent text-xs uppercase tracking-[0.25em] text-teal-100/90">
                Hammad Web Designer
              </span>
            </motion.div>

            {/* CRASH NAME — letters fall + crash into place */}
            <div className="font-display uppercase leading-[0.86]">
              <WaterfallName
                lines={["HAMMAD"]}
                delay={baseDelay}
                stagger={stagger}
                crash
                letterClassName="text-chrome"
                className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem]"
              />
              <div className="relative mt-1">
                <WaterfallName
                  lines={["KHADIM"]}
                  delay={khadimDelay}
                  stagger={stagger}
                  crash
                  accent="#2ee6c8"
                  letterClassName="brand-teal text-glow-teal"
                  className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem]"
                />
                {/* teal underline swoosh — reveals after crash */}
                <motion.div
                  aria-hidden
                  className="absolute -bottom-1 left-0 right-0 mx-auto h-[0.14em] w-[92%] origin-left rounded-full"
                  style={{
                    background:
                      "linear-gradient(90deg, transparent, #2ee6c8 18%, #5eead4 50%, #2ee6c8 82%, transparent)",
                    filter: "drop-shadow(0 0 10px rgba(45,212,191,0.7))",
                    transform: "rotate(-1.4deg)",
                  }}
                  initial={reduced ? { opacity: 0 } : { scaleX: 0, opacity: 0 }}
                  animate={{ scaleX: 1, opacity: 1 }}
                  transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: swooshDelay }}
                />
              </div>
            </div>

            {/* professional title — reveals after crash */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: titleDelay }}
              className="mt-5 flex flex-wrap items-center gap-x-2 gap-y-1 font-accent text-base sm:text-lg md:text-xl"
            >
              <span className="font-semibold text-white">WEB DESIGNER</span>
              <span className="text-teal-300/70">|</span>
              <span className="inline-flex items-center gap-1.5 font-semibold">
                <ShopifyLogo size={18} withWordmark />
                <span className="text-teal-300 text-glow-teal">EXPERT</span>
              </span>
            </motion.div>

            {/* description */}
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: descDelay }}
              className="mt-4 max-w-xl text-base text-muted-foreground sm:text-lg"
            >
              I create exceptional digital experiences through modern web design,
              creative UI/UX, and powerful website development.
            </motion.p>

            {/* CTAs — Explore My Work reveals last */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: ctaDelay }}
              className="mt-7 flex flex-wrap items-center gap-4"
            >
              <Magnetic as="div" strength={0.4}>
                <button
                  onClick={() => scrollTo("#projects")}
                  className="btn-glow group flex items-center gap-2 rounded-full px-7 py-3.5 font-accent text-sm uppercase tracking-wider"
                >
                  Explore My Work
                  <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </button>
              </Magnetic>
              <Magnetic as="div" strength={0.3}>
                <button
                  onClick={() => scrollTo("#contact")}
                  className="btn-ghost-glow flex items-center gap-2 rounded-full px-7 py-3.5 font-accent text-sm uppercase tracking-wider"
                >
                  Let&apos;s Work Together
                </button>
              </Magnetic>
            </motion.div>
          </div>

          {/* RIGHT — portrait fades in from the right after the crash */}
          <motion.div
            className="relative order-1 mx-auto w-full max-w-[18rem] sm:max-w-sm md:max-w-md lg:order-2 lg:col-span-5"
            initial={reduced ? { opacity: 0 } : { opacity: 0, x: 70 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: crashImpactAt - 0.15 }}
          >
            <AnimatedPortrait src="/images/portrait.png" />
          </motion.div>
        </div>

        {/* ===== BOTTOM STATS BAR ===== */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: crashImpactAt + 0.35 }}
          className="mx-auto mt-8 w-full max-w-7xl px-4 sm:px-6"
        >
          <div className="grid grid-cols-2 divide-x divide-white/10 rounded-2xl glass-strong py-4 md:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.label} className="flex items-center justify-center gap-3 px-3 py-2 text-center md:px-5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-teal-400/30 bg-teal-500/10 text-teal-300">
                  {s.icon}
                </div>
                <div className="flex flex-col leading-tight">
                  <span className="font-display text-sm uppercase text-white sm:text-base">{s.value}</span>
                  <span className="font-accent text-[0.6rem] uppercase tracking-wider text-muted-foreground">
                    {s.label}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
