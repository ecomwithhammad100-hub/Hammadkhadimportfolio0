"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useMemo } from "react";
import { cn } from "@/lib/utils";

type WaterfallNameProps = {
  /** Lines to render, e.g. ["HAMMAD", "KHADIM"] */
  lines: string[];
  className?: string;
  lineClassName?: string;
  /** class applied directly to each letter span (use for per-letter color) */
  letterClassName?: string;
  /** per-letter stagger (seconds) */
  stagger?: number;
  /** base delay before the first letter falls (seconds) */
  delay?: number;
  /** accent (teal) color for the glow trail */
  accent?: string;
  /** crash mode: harder gravity fall with a pronounced bounce on landing */
  crash?: boolean;
};

/**
 * Cinematic name reveal. Each letter falls from above the viewport with
 * gravity-inspired motion, a turquoise blur trail, and settles into place.
 *
 * In `crash` mode the fall is faster/harder with a pronounced bounce,
 * designed to pair with a CrashImpact shockwave at the landing moment.
 *
 * Respects prefers-reduced-motion (letters simply fade/slide in gently).
 */
export function WaterfallName({
  lines,
  className,
  lineClassName,
  letterClassName,
  stagger = 0.07,
  delay = 0.3,
  accent = "#2dd4bf",
  crash = false,
}: WaterfallNameProps) {
  const reduced = useReducedMotion();

  const letters = useMemo(() => {
    return lines.map((line, li) =>
      line.split("").map((ch, ci) => ({ ch, li, ci, key: `${li}-${ci}` })),
    );
  }, [lines]);

  const totalLetters = lines.reduce((n, l) => n + l.length, 0);
  let counter = 0;

  // crash-mode physics: stiffer spring, lower damping → fast hard fall + bounce
  const stiffness = reduced ? 200 : crash ? 210 : 130;
  const damping = reduced ? 26 : crash ? 9 : 13;
  const mass = reduced ? 0.3 : crash ? 1.15 : 0.9;
  const blurAmount = crash ? 14 : 10;

  return (
    <motion.div
      className={cn("relative", className)}
      initial="hidden"
      animate="visible"
    >
      {letters.map((lineLetters, li) => (
        <div key={li} className={cn("flex justify-center overflow-visible", lineClassName)}>
          {lineLetters.map(({ ch, key }) => {
            const index = counter++;
            const letterDelay = delay + index * stagger;
            // crash: higher fall origin for a more dramatic drop
            const fallY = reduced ? 40 : crash ? -(360 + ((index * 53) % 220)) : -(220 + ((index * 53) % 180));
            const driftX = reduced ? 0 : ((index * 37) % 24) - 12;

            return (
              <span key={key} className="inline-block overflow-visible">
                <motion.span
                  className={cn("inline-block", letterClassName)}
                  variants={{
                    hidden: {
                      y: fallY,
                      x: driftX,
                      opacity: 0,
                      filter: `blur(${blurAmount}px)`,
                      rotate: reduced ? 0 : ((index * 29) % 16) - 8,
                      textShadow: crash
                        ? `0 0 34px ${accent}, 0 0 70px ${accent}, 0 0 110px ${accent}`
                        : `0 0 28px ${accent}, 0 0 60px ${accent}`,
                    },
                    visible: {
                      y: 0,
                      x: 0,
                      opacity: 1,
                      filter: "blur(0px)",
                      rotate: 0,
                      textShadow: "0 0 0px transparent",
                    },
                  }}
                  transition={{
                    type: "spring",
                    stiffness,
                    damping,
                    mass,
                    delay: letterDelay,
                  }}
                >
                  {ch}
                </motion.span>
              </span>
            );
          })}
        </div>
      ))}

      {/* impact pulse when the name lands */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-0 rounded-xl"
        style={{ boxShadow: `0 0 0 0 ${accent}` }}
        initial={{ opacity: 0 }}
        animate={
          reduced
            ? { opacity: 0 }
            : {
                opacity: [0, 0, crash ? 0.7 : 0.5, 0],
                boxShadow: [
                  `0 0 0 0 ${accent}00`,
                  `0 0 0 0 ${accent}00`,
                  crash
                    ? `0 0 60px 14px ${accent}66`
                    : `0 0 40px 8px ${accent}55`,
                  `0 0 0 0 ${accent}00`,
                ],
              }
        }
        transition={{
          duration: crash ? 1 : 0.8,
          times: [0, 0.5, 0.68, 1],
          delay: delay + totalLetters * stagger + 0.02,
        }}
      />
    </motion.div>
  );
}
