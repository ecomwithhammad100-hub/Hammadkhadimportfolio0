"use client";

import { animate, motion, useInView, useMotionValue, useTransform } from "framer-motion";
import { Briefcase, Layers, Rocket, ShoppingBag } from "lucide-react";
import { useEffect, useRef } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";

type Stat = {
  value: string;
  suffix?: string;
  countTo?: number;
  label: string;
  sub: string;
  icon: typeof Briefcase;
};

const STATS: Stat[] = [
  {
    value: "8–10",
    label: "Local Projects",
    sub: "Hands-on project experience",
    icon: Briefcase,
  },
  {
    value: "6+",
    countTo: 6,
    suffix: "+",
    label: "Live Platforms",
    sub: "Multiple independent digital projects",
    icon: Layers,
  },
  {
    value: "Shopify + Web",
    label: "Development",
    sub: "Shopify and website development",
    icon: ShoppingBag,
  },
  {
    value: "100%",
    countTo: 100,
    suffix: "%",
    label: "Independent",
    sub: "Built end-to-end, business-focused",
    icon: Rocket,
  },
];

const ACHIEVEMENTS = [
  "8–10 Local Projects",
  "Shopify & Website Development",
  "Multiple Independent Digital Projects",
  "Business-Focused Digital Solutions",
];

export function Stats() {
  return (
    <section id="experience" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[50vh] w-[80vh] -translate-x-1/2 -translate-y-1/2 rounded-full bg-teal-700/10 blur-[160px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-14 flex flex-col gap-4">
          <Reveal>
            <div className="flex items-center gap-3">
              <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">05</span>
              <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                Experience
              </span>
            </div>
          </Reveal>
          <AnimatedText
            text="Experience That Builds Trust."
            as="h2"
            className="font-display max-w-3xl text-4xl uppercase leading-[0.95] text-white sm:text-5xl md:text-6xl"
          />
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((stat, i) => (
            <StatCard key={stat.label} stat={stat} index={i} />
          ))}
        </div>

        {/* achievement strip */}
        <Reveal delay={0.15}>
          <div className="mt-10 grid grid-cols-1 gap-4 rounded-3xl gradient-border p-6 sm:grid-cols-2 lg:grid-cols-4">
            {ACHIEVEMENTS.map((item, i) => (
              <div key={item} className="flex items-center gap-3">
                <span className="font-display text-2xl text-teal-300 text-glow-teal">
                  0{i + 1}
                </span>
                <span className="text-sm text-muted-foreground sm:text-base">{item}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function StatCard({ stat, index }: { stat: Stat; index: number }) {
  const reduced = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15% 0px" });
  const count = useMotionValue(0);
  const rounded = useTransform(count, (v) => Math.round(v).toString());

  useEffect(() => {
    if (!inView || reduced || stat.countTo == null) return;
    const controls = animate(count, stat.countTo, {
      duration: 1.6,
      ease: [0.22, 1, 0.36, 1],
    });
    return () => controls.stop();
  }, [inView, reduced, stat.countTo, count]);

  const Icon = stat.icon;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="group relative overflow-hidden rounded-3xl gradient-border p-6 neon-border-hover"
    >
      <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-teal-500/10 blur-2xl transition-opacity duration-500 group-hover:bg-teal-500/20" />

      <div className="relative flex items-center justify-between">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-teal-400/30 bg-teal-500/10 text-teal-300 transition-transform duration-300 group-hover:scale-110">
          <Icon className="h-5 w-5" />
        </div>
        <span className="font-accent text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground">
          0{index + 1}
        </span>
      </div>

      <div className="relative mt-6 font-display text-4xl leading-none text-white sm:text-5xl">
        {stat.countTo != null ? (
          <span className="inline-flex items-baseline">
            <motion.span>{rounded}</motion.span>
            {stat.suffix && <span className="text-teal-300 text-glow-teal">{stat.suffix}</span>}
          </span>
        ) : (
          <span className="gradient-text">{stat.value}</span>
        )}
      </div>

      <div className="relative mt-3 font-display text-base uppercase tracking-wide text-teal-100/90">
        {stat.label}
      </div>
      <div className="relative mt-1 text-sm text-muted-foreground">{stat.sub}</div>
    </motion.div>
  );
}
