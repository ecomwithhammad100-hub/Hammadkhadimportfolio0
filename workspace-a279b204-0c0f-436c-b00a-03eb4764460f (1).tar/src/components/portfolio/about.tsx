"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { CheckCircle2, Code2, PenTool, Sparkles } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";

const FOCUS = [
  "Modern Web Design",
  "Creative UI/UX",
  "Shopify Development",
  "Business-Focused Digital Solutions",
];

const PILLARS = [
  { icon: PenTool, title: "Design", desc: "Beautiful, modern, functional interfaces." },
  { icon: Code2, title: "Development", desc: "Clean, performant, hand-crafted code." },
  { icon: Sparkles, title: "Experience", desc: "Memorable, business-driven UX." },
];

export function About() {
  const reduced = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const imgY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const textY = useTransform(scrollYProgress, [0, 1], [30, -30]);

  return (
    <section id="about" ref={ref} className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-14 flex flex-col gap-4">
          <Reveal>
            <div className="flex items-center gap-3">
              <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">01</span>
              <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                About Me
              </span>
            </div>
          </Reveal>
          <AnimatedText
            text="THE PERSON BEHIND THE PIXELS."
            as="h2"
            className="font-display max-w-4xl text-4xl uppercase leading-[0.95] text-white sm:text-5xl md:text-6xl"
          />
        </div>

        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-2 lg:gap-12">
          {/* LEFT — image */}
          <motion.div style={{ y: reduced ? 0 : imgY }} className="relative order-1">
            <div className="relative aspect-[4/5] w-full overflow-hidden rounded-3xl gradient-border">
              <Image
                src="/images/portrait.png"
                alt="Hammad Khadim — Web Designer and Shopify Expert portrait"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover object-top"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.6 }}
                className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-4 rounded-2xl glass-strong px-4 py-3"
              >
                <div>
                  <div className="font-display text-lg uppercase text-white">Hammad Khadim</div>
                  <div className="font-accent text-[0.65rem] uppercase tracking-[0.25em] text-teal-300/70">
                    Web Designer
                  </div>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full border border-teal-400/40 bg-teal-500/10">
                  <Sparkles className="h-4 w-4 text-teal-300" />
                </div>
              </motion.div>
            </div>
            <div className="pointer-events-none absolute -inset-3 -z-10 rounded-[2rem] border border-teal-400/10" />
          </motion.div>

          {/* RIGHT — text */}
          <motion.div style={{ y: reduced ? 0 : textY }} className="order-2 flex flex-col justify-center gap-6">
            <Reveal>
              <p className="text-lg text-muted-foreground sm:text-xl">
                I&apos;m{" "}
                <span className="font-medium text-teal-200">Hammad Khadim</span>, a
                creative Web Designer and Shopify Expert passionate about
                designing beautiful, modern, and functional digital experiences.
              </p>
            </Reveal>

            <Reveal delay={0.15}>
              <ul className="flex flex-col gap-3">
                {FOCUS.map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-teal-400" />
                    <span className="text-base text-white/90">{item}</span>
                  </li>
                ))}
              </ul>
            </Reveal>

            <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
              {PILLARS.map((p, i) => (
                <motion.div
                  key={p.title}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.1, duration: 0.6 }}
                  className="group rounded-2xl glass p-4 neon-border-hover"
                >
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500/10 text-teal-300 transition-transform duration-300 group-hover:scale-110">
                    <p.icon className="h-5 w-5" />
                  </div>
                  <div className="font-display text-sm uppercase tracking-wide text-white">
                    {p.title}
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">{p.desc}</div>
                </motion.div>
              ))}
            </div>

            <Reveal delay={0.3}>
              <blockquote className="mt-4 border-l-2 border-teal-400/50 pl-4 font-accent text-base italic text-teal-100/80">
                &ldquo;Every pixel has a purpose — I design experiences that look
                beautiful and work brilliantly.&rdquo;
              </blockquote>
            </Reveal>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
