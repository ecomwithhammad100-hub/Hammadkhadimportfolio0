"use client";

import { ArrowUp, Heart, Instagram, Linkedin, Github } from "lucide-react";
import { Reveal } from "./reveal";

const NAV = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Services", href: "#services" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

const SOCIALS = [
  { icon: Instagram, href: "https://instagram.com/", label: "Instagram" },
  { icon: Linkedin, href: "https://linkedin.com/", label: "LinkedIn" },
  { icon: Github, href: "https://github.com/", label: "GitHub" },
];

export function Footer() {
  const go = (href: string) =>
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth", block: "start" });

  const toTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <footer className="relative mt-auto border-t border-teal-400/10 bg-black/40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-teal-400/40 to-transparent" />

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-3">
          {/* brand — text name, no logo */}
          <Reveal>
            <div className="flex flex-col gap-3">
              <button onClick={() => go("#home")} className="group flex w-fit flex-col leading-none">
                <span className="font-display text-xl uppercase tracking-[0.18em] text-white">
                  Hammad <span className="brand-teal text-glow-teal">Khadim</span>
                </span>
                <span className="font-accent text-[0.55rem] uppercase tracking-[0.35em] text-teal-300/60">
                  Web Designer &amp; Shopify Expert
                </span>
              </button>
              <p className="max-w-xs text-sm text-muted-foreground">
                Creating exceptional digital experiences through modern web
                design, creative UI/UX, and powerful website development.
              </p>
            </div>
          </Reveal>

          {/* nav */}
          <Reveal delay={0.1}>
            <div className="flex flex-col gap-3">
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/70">
                Navigate
              </span>
              <ul className="grid grid-cols-2 gap-2">
                {NAV.map((item) => (
                  <li key={item.href}>
                    <button
                      onClick={() => go(item.href)}
                      className="text-sm text-muted-foreground transition-colors hover:text-teal-200"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* socials + back to top */}
          <Reveal delay={0.2}>
            <div className="flex flex-col gap-3">
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/70">
                Connect
              </span>
              <div className="flex gap-3">
                {SOCIALS.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-muted-foreground transition-all duration-300 hover:border-teal-300/60 hover:text-teal-300 hover:shadow-[0_0_20px_rgba(45,212,191,0.4)]"
                  >
                    <s.icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
              <button
                onClick={toTop}
                className="group mt-2 flex w-fit items-center gap-2 rounded-full border border-teal-400/30 px-4 py-2 font-accent text-xs uppercase tracking-widest text-teal-200 transition-all duration-300 hover:border-teal-300 hover:bg-teal-500/10"
              >
                Back to Top
                <ArrowUp className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-0.5" />
              </button>
            </div>
          </Reveal>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-center sm:flex-row sm:text-left">
          <p className="font-accent text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Hammad Khadim. All rights reserved.
          </p>
          <p className="flex items-center gap-1.5 font-accent text-xs text-muted-foreground">
            Crafted with <Heart className="h-3 w-3 text-teal-400" /> &amp; clean code
          </p>
        </div>
      </div>
    </footer>
  );
}
