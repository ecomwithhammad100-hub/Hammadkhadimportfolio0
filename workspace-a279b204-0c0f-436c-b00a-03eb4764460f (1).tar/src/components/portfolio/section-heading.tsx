"use client";

import { cn } from "@/lib/utils";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";

type SectionHeadingProps = {
  eyebrow?: string;
  index?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
};

export function SectionHeading({
  eyebrow,
  index,
  title,
  description,
  align = "left",
  className,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "flex flex-col gap-4",
        align === "center" && "items-center text-center",
        className,
      )}
    >
      {(eyebrow || index) && (
        <Reveal>
          <div className="flex items-center gap-3">
            {index && (
              <span className="font-accent text-xs tracking-[0.3em] text-emerald-400/70">
                {index}
              </span>
            )}
            {eyebrow && (
              <>
                <span className="h-px w-8 bg-gradient-to-r from-emerald-400/80 to-transparent" />
                <span className="font-accent text-xs uppercase tracking-[0.3em] text-emerald-300/80">
                  {eyebrow}
                </span>
              </>
            )}
          </div>
        </Reveal>
      )}

      <AnimatedText
        text={title}
        as="h2"
        split="word"
        className={cn(
          "font-display text-4xl uppercase leading-[0.95] text-foreground sm:text-5xl md:text-6xl",
          align === "center" && "justify-center",
        )}
      />

      {description && (
        <Reveal delay={0.15}>
          <p
            className={cn(
              "max-w-2xl text-base text-muted-foreground sm:text-lg",
              align === "center" && "mx-auto",
            )}
          >
            {description}
          </p>
        </Reveal>
      )}
    </div>
  );
}
