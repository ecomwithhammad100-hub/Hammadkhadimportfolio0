"use client";

import {
  motion,
  useMotionTemplate,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import Image from "next/image";
import { type ReactNode, useRef, type MouseEvent } from "react";
import { Code2, TrendingUp } from "lucide-react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { ShopifyMark } from "./shopify-logo";
import { cn } from "@/lib/utils";

type Badge = {
  content: ReactNode;
  top?: string;
  bottom?: string;
  left?: string;
  right?: string;
  /** parallax depth (0 = moves most, 1 = moves least) */
  depth?: number;
  delay?: number;
};

const DEFAULT_BADGES: Badge[] = [
  { content: <><ShopifyMark size={16} /> Shopify</>, top: "5%", left: "-12%", depth: 0.55, delay: 0 },
  { content: <><Code2 className="h-4 w-4 text-teal-300" /> Developer</>, top: "30%", right: "-14%", depth: 0.4, delay: 0.2 },
  { content: <><TrendingUp className="h-4 w-4 text-teal-300" /> Growth</>, bottom: "16%", left: "-10%", depth: 0.65, delay: 0.45 },
];

// floating particles around the shoulders/head
const PARTICLES = Array.from({ length: 11 }, (_, i) => ({
  id: i,
  left: `${8 + ((i * 83) % 84)}%`,
  top: `${(i * 47) % 70}%`,
  size: 2 + ((i * 13) % 3),
  dur: 4 + ((i * 7) % 5),
  delay: (i * 0.5) % 3,
}));

export function AnimatedPortrait({
  src = "/images/portrait.png",
  badges = DEFAULT_BADGES,
  className,
}: {
  src?: string;
  badges?: Badge[];
  className?: string;
}) {
  const reduced = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);

  // mouse-based 3D tilt + parallax
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const tiltX = useSpring(useTransform(my, [-0.5, 0.5], [10, -10]), { stiffness: 120, damping: 18 });
  const tiltY = useSpring(useTransform(mx, [-0.5, 0.5], [-12, 12]), { stiffness: 120, damping: 18 });
  const auraX = useSpring(useTransform(mx, [-0.5, 0.5], [18, -18]), { stiffness: 50, damping: 20 });
  const auraY = useSpring(useTransform(my, [-0.5, 0.5], [12, -12]), { stiffness: 50, damping: 20 });
  const ringX = useSpring(useTransform(mx, [-0.5, 0.5], [28, -28]), { stiffness: 60, damping: 22 });
  const ringY = useSpring(useTransform(my, [-0.5, 0.5], [20, -20]), { stiffness: 60, damping: 22 });

  // cursor-following dynamic lighting
  const lightX = useTransform(mx, [-0.5, 0.5], ["30%", "70%"]);
  const lightY = useTransform(my, [-0.5, 0.5], ["30%", "70%"]);
  const lightBg = useMotionTemplate`radial-gradient(circle at ${lightX} ${lightY}, rgba(45,212,191,0.22), transparent 55%)`;

  // scroll-based scale + parallax (on the outer container)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const scrollScale = useTransform(scrollYProgress, [0, 1], [1, 0.86]);
  const scrollY = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const scrollOpacity = useTransform(scrollYProgress, [0, 0.8, 1], [1, 1, 0.4]);

  function onMouseMove(e: MouseEvent<HTMLDivElement>) {
    if (reduced || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    mx.set((e.clientX - (r.left + r.width / 2)) / r.width);
    my.set((e.clientY - (r.top + r.height / 2)) / r.height);
  }
  function onMouseLeave() {
    mx.set(0);
    my.set(0);
  }

  return (
    <div
      ref={ref}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
      className={cn("relative aspect-[3/4] w-full", className)}
      style={{ perspective: 1200 }}
    >
      {/* ===== AURA GLOW (pulsing) ===== */}
      <motion.div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-30 h-[120%] w-[120%] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          x: reduced ? 0 : auraX,
          y: reduced ? 0 : auraY,
          background:
            "radial-gradient(circle, rgba(16,185,129,0.28) 0%, rgba(20,184,166,0.16) 40%, transparent 70%)",
          filter: "blur(30px)",
        }}
        animate={reduced ? {} : { scale: [1, 1.08, 1], opacity: [0.6, 0.9, 0.6] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* ===== ANIMATED BACKGROUND RINGS ===== */}
      <motion.div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-20 h-[92%] w-[92%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-teal-400/20"
        style={{ x: reduced ? 0 : ringX, y: reduced ? 0 : ringY }}
        animate={reduced ? {} : { rotate: 360 }}
        transition={{ duration: 36, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-20 h-[108%] w-[108%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-teal-400/15"
        style={{ x: reduced ? 0 : ringX, y: reduced ? 0 : ringY }}
        animate={reduced ? {} : { rotate: -360 }}
        transition={{ duration: 48, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-20 h-[78%] w-[78%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/10"
        animate={reduced ? {} : { rotate: 360 }}
        transition={{ duration: 24, repeat: Infinity, ease: "linear" }}
      />

      {/* ===== ENTRANCE LIGHT BURST ===== */}
      {!reduced && (
        <motion.div
          aria-hidden
          className="absolute left-1/2 top-1/2 -z-10 h-[60%] w-[60%] -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(45,212,191,0.6), transparent 60%)",
            filter: "blur(20px)",
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [0, 1.8, 2.4], opacity: [0, 0.7, 0] }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
        />
      )}

      {/* ===== FLOATING PARTICLES ===== */}
      {!reduced &&
        PARTICLES.map((p) => (
          <motion.span
            key={p.id}
            aria-hidden
            className="absolute z-20 rounded-full bg-teal-300"
            style={{
              left: p.left,
              top: p.top,
              width: p.size,
              height: p.size,
              boxShadow: "0 0 8px rgba(45,212,191,0.8)",
            }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: [0, 1, 0], y: [0, -18, -36] }}
            transition={{ duration: p.dur, repeat: Infinity, delay: p.delay, ease: "easeInOut" }}
          />
        ))}

      {/* ===== PORTRAIT — outer (scroll scale/parallax + 3D tilt) ===== */}
      <motion.div
        className="relative h-full w-full"
        style={{
          rotateX: reduced ? 0 : tiltX,
          rotateY: reduced ? 0 : tiltY,
          transformStyle: "preserve-3d",
          scale: reduced ? 1 : scrollScale,
          y: reduced ? 0 : scrollY,
          opacity: reduced ? 1 : scrollOpacity,
        }}
      >
        {/* inner — gentle float (separate from scroll y) */}
        <motion.div
          className="relative h-full w-full"
          animate={reduced ? {} : { y: [0, -14, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        >
          {/* layered drop shadows for depth */}
          <div aria-hidden className="absolute inset-0 -z-10 translate-y-3 rounded-[2rem] bg-black/50 blur-2xl" />
          <div aria-hidden className="absolute inset-0 -z-10 translate-y-6 rounded-[2rem] bg-teal-900/20 blur-3xl" />

          {/* cinematic mask reveal + image */}
          <motion.div
            className="relative h-full w-full overflow-hidden rounded-[2rem] border border-teal-400/30"
            initial={reduced ? { opacity: 0 } : { clipPath: "inset(100% 0 0 0)", opacity: 0, scale: 1.08 }}
            animate={{ clipPath: "inset(0% 0 0 0)", opacity: 1, scale: 1 }}
            transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: 0.35 }}
          >
            <Image
              src={src}
              alt="Portrait of Hammad Khadim — Web Designer and Shopify Expert"
              fill
              priority
              loading="eager"
              sizes="(max-width: 1024px) 90vw, 40vw"
              className="object-cover object-top"
            />

            {/* cursor-following dynamic lighting */}
            <motion.div
              aria-hidden
              className="pointer-events-none absolute inset-0 z-10 mix-blend-screen"
              style={{ background: reduced ? "none" : lightBg }}
            />

            {/* moving light sweep */}
            {!reduced && (
              <motion.div
                aria-hidden
                className="pointer-events-none absolute inset-0 z-10 overflow-hidden"
              >
                <motion.div
                  className="absolute -inset-y-4 -left-1/3 w-1/3 rotate-12"
                  style={{
                    background:
                      "linear-gradient(90deg, transparent, rgba(94,234,212,0.18), rgba(255,255,255,0.22), rgba(94,234,212,0.18), transparent)",
                    filter: "blur(2px)",
                  }}
                  animate={{ x: ["-30%", "330%"] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", repeatDelay: 3 }}
                />
              </motion.div>
            )}

            {/* neon rim lighting (inset) */}
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0 z-10 rounded-[2rem] shadow-[inset_0_0_60px_rgba(45,212,191,0.28),inset_0_0_140px_rgba(0,0,0,0.6)]"
            />
            <div
              aria-hidden
              className="pointer-events-none absolute inset-x-0 top-0 z-10 h-1/3 rounded-[2rem] bg-gradient-to-b from-teal-400/15 to-transparent"
            />
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0 z-10 rounded-[2rem] bg-gradient-to-t from-black/70 via-transparent to-transparent"
            />

            {/* animated silhouette outline (pulsing border glow) */}
            <motion.div
              aria-hidden
              className="pointer-events-none absolute inset-0 z-20 rounded-[2rem] border border-teal-300/40"
              animate={
                reduced
                  ? {}
                  : {
                      boxShadow: [
                        "0 0 18px rgba(45,212,191,0.25), inset 0 0 18px rgba(45,212,191,0.08)",
                        "0 0 36px rgba(45,212,191,0.5), inset 0 0 24px rgba(45,212,191,0.15)",
                        "0 0 18px rgba(45,212,191,0.25), inset 0 0 18px rgba(45,212,191,0.08)",
                      ],
                    }
              }
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
          </motion.div>
        </motion.div>
      </motion.div>

      {/* ===== FLOATING SKILL BADGES (each with its own parallax depth) ===== */}
      {badges.map((b, i) => (
        <FloatingBadge key={i} badge={b} mx={mx} my={my} reduced={reduced} index={i} />
      ))}
    </div>
  );
}

/** Sub-component so hooks (useTransform) are called at the top level, not in a loop. */
function FloatingBadge({
  badge,
  mx,
  my,
  reduced,
  index,
}: {
  badge: Badge;
  mx: ReturnType<typeof useMotionValue>;
  my: ReturnType<typeof useMotionValue>;
  reduced: boolean;
  index: number;
}) {
  const depth = badge.depth ?? 0.5;
  const amount = (1 - depth) * 30;
  const bX = useTransform(mx, [-0.5, 0.5], [amount, -amount]);
  const bY = useTransform(my, [-0.5, 0.5], [amount * 0.75, -amount * 0.75]);

  return (
    <motion.div
      className="absolute z-30 hidden sm:block"
      style={{
        top: badge.top,
        bottom: badge.bottom,
        left: badge.left,
        right: badge.right,
        x: reduced ? 0 : bX,
        y: reduced ? 0 : bY,
      }}
      initial={{ opacity: 0, scale: 0.8, y: 12 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 1.4 + (badge.delay ?? 0) }}
    >
      <motion.div
        animate={reduced ? {} : { y: [0, -8, 0] }}
        transition={{ duration: 4 + index, repeat: Infinity, ease: "easeInOut", delay: badge.delay }}
      >
        <div className="flex items-center gap-1.5 rounded-xl glass-strong px-3 py-2 font-accent text-xs text-white">
          {badge.content}
        </div>
      </motion.div>
    </motion.div>
  );
}
