"use client";

import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import {
  Braces,
  Code2,
  LayoutDashboard,
  LayoutTemplate,
  Monitor,
  Palette,
  PenTool,
  Smartphone,
} from "lucide-react";
import { type ReactNode, useRef, type MouseEvent } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";
import { ShopifyMark } from "./shopify-logo";
import { cn } from "@/lib/utils";

type Skill = {
  name: string;
  icon: ReactNode;
  tier: "Expert" | "Advanced" | "Proficient";
  blurb: string;
};

const SKILLS: Skill[] = [
  { name: "UI/UX Design", icon: <PenTool className="h-6 w-6" />, tier: "Expert", blurb: "User-centred interfaces & design systems." },
  { name: "Website Design", icon: <Monitor className="h-6 w-6" />, tier: "Expert", blurb: "Modern, art-directed web design." },
  { name: "Shopify Development", icon: <ShopifyMark size={24} />, tier: "Expert", blurb: "Full store builds that convert." },
  { name: "Shopify Liquid", icon: <ShopifyMark size={24} />, tier: "Expert", blurb: "Deep Liquid templating & overrides." },
  { name: "HTML5", icon: <Code2 className="h-6 w-6" />, tier: "Expert", blurb: "Semantic, accessible markup." },
  { name: "CSS3", icon: <Palette className="h-6 w-6" />, tier: "Expert", blurb: "Modern layout, animation, glassmorphism." },
  { name: "JavaScript", icon: <Braces className="h-6 w-6" />, tier: "Advanced", blurb: "Interactive UIs & dynamic behaviour." },
  { name: "Responsive Design", icon: <Smartphone className="h-6 w-6" />, tier: "Expert", blurb: "Flawless across every device." },
  { name: "Landing Page Design", icon: <LayoutTemplate className="h-6 w-6" />, tier: "Expert", blurb: "High-impact, conversion-focused pages." },
  { name: "Custom Website Development", icon: <Code2 className="h-6 w-6" />, tier: "Advanced", blurb: "Tailored business websites." },
  { name: "Admin Dashboard Design", icon: <LayoutDashboard className="h-6 w-6" />, tier: "Advanced", blurb: "Clean dashboards & internal tools." },
];

const TIER_COLOR: Record<Skill["tier"], string> = {
  Expert: "text-teal-300 border-teal-400/40 bg-teal-500/10",
  Advanced: "text-cyan-200 border-cyan-400/40 bg-cyan-500/10",
  Proficient: "text-emerald-200 border-emerald-400/40 bg-emerald-500/10",
};

export function Skills() {
  const reduced = useReducedMotion();

  return (
    <section id="skills" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-1/3 -z-10 h-[40vh] w-[60vh] -translate-x-1/2 rounded-full bg-teal-600/10 blur-[140px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-14 flex flex-col gap-4">
          <Reveal>
            <div className="flex items-center gap-3">
              <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">02</span>
              <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                Professional Skills
              </span>
            </div>
          </Reveal>
          <AnimatedText
            text="A Full Creative & Dev Toolkit."
            as="h2"
            className="font-display max-w-3xl text-4xl uppercase leading-[0.95] text-white sm:text-5xl md:text-6xl"
          />
          <Reveal delay={0.15}>
            <p className="max-w-2xl text-base text-muted-foreground sm:text-lg">
              Design, front-end engineering, and Shopify — a focused stack for
              shipping complete, beautiful digital products.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SKILLS.map((skill, i) => (
            <SkillCard key={skill.name} skill={skill} index={i} reduced={reduced} />
          ))}
        </div>

        {/* marquee strip */}
        <Reveal delay={0.2}>
          <div className="relative mt-12 overflow-hidden rounded-2xl border border-teal-400/15 bg-white/[0.02] py-4">
            <div className="flex shrink-0 animate-marquee gap-12 pr-12" style={{ width: "max-content" }}>
              {[...SKILLS, ...SKILLS].map((s, i) => (
                <span
                  key={`${s.name}-${i}`}
                  className="flex shrink-0 items-center gap-2 font-accent text-sm uppercase tracking-widest text-muted-foreground"
                >
                  <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-teal-400/60" />
                  {s.name}
                </span>
              ))}
            </div>
            <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-background to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-background to-transparent" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function SkillCard({
  skill,
  index,
  reduced,
}: {
  skill: Skill;
  index: number;
  reduced: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 200, damping: 18 });
  const sry = useSpring(ry, { stiffness: 200, damping: 18 });
  const rotateX = useTransform(sry, [-0.5, 0.5], ["8deg", "-8deg"]);
  const rotateY = useTransform(srx, [-0.5, 0.5], ["-8deg", "8deg"]);

  function onMove(e: MouseEvent<HTMLDivElement>) {
    if (reduced || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    rx.set((e.clientX - (r.left + r.width / 2)) / r.width);
    ry.set((e.clientY - (r.top + r.height / 2)) / r.height);
  }
  function onLeave() {
    rx.set(0);
    ry.set(0);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      style={{ perspective: 1000 }}
    >
      <motion.div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        style={reduced ? {} : { rotateX, rotateY, transformStyle: "preserve-3d" }}
        className="group relative h-full overflow-hidden rounded-2xl gradient-border p-6 neon-border-hover"
      >
        <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
          <div className="absolute -top-12 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-teal-500/20 blur-3xl" />
        </div>

        <div className="relative flex items-start justify-between" style={{ transform: "translateZ(40px)" }}>
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-teal-400/30 bg-teal-500/10 text-teal-300 transition-all duration-300 group-hover:scale-110 group-hover:border-teal-300/60">
            {skill.icon}
          </div>
          <span
            className={cn(
              "rounded-full border px-2.5 py-1 font-accent text-[0.6rem] uppercase tracking-widest",
              TIER_COLOR[skill.tier],
            )}
          >
            {skill.tier}
          </span>
        </div>

        <h3 className="relative mt-5 font-display text-xl uppercase leading-tight text-white" style={{ transform: "translateZ(30px)" }}>
          {skill.name}
        </h3>
        <p className="relative mt-2 text-sm text-muted-foreground" style={{ transform: "translateZ(20px)" }}>
          {skill.blurb}
        </p>

        <div className="relative mt-5 h-1 w-full overflow-hidden rounded-full bg-white/5">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-teal-400 to-cyan-300"
            initial={{ width: "0%" }}
            whileInView={{
              width: skill.tier === "Expert" ? "92%" : skill.tier === "Advanced" ? "70%" : "55%",
            }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.3 + index * 0.05, ease: [0.22, 1, 0.36, 1] }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
