"use client";

import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowUpRight, ExternalLink, Tag } from "lucide-react";
import Image from "next/image";
import { useRef, type MouseEvent } from "react";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";
import { cn } from "@/lib/utils";

type Project = {
  name: string;
  category: string;
  image: string;
  description: string;
  /** Real live demo URL. When undefined, the Live Demo button is hidden. */
  demoUrl?: string;
  featured?: boolean;
};

const PROJECTS: Project[] = [
  {
    name: "Numify",
    category: "Virtual Number Platform",
    image: "/images/projects/numify.png",
    description:
      "A premium virtual number marketplace with a secure, professional interface for exploring number services across countries and platforms.",
    demoUrl: "https://numify.space-z.ai/#/home",
    featured: true,
  },
  {
    name: "Pak Panel",
    category: "SMM Panel Platform",
    image: "/images/projects/pak-panel.png",
    description:
      "A social media marketing panel for growing digital presence, with service packages, order tracking, and a clean dashboard.",
    demoUrl: "https://pakpanel.space-z.ai",
  },
  {
    name: "APKHub",
    category: "Digital App Platform",
    image: "/images/projects/apkhub.png",
    description:
      "A digital app platform with categorised listings, downloads, and a modern discovery interface.",
    demoUrl: "https://apkhub1.space-z.ai/#/",
  },
  {
    name: "Adnexa",
    category: "Digital Advertising Platform",
    image: "/images/projects/adnexa.png",
    description:
      "A digital advertising platform for campaign management, performance tracking, and reporting.",
    demoUrl: "https://adnexa.space-z.ai/#/",
  },
  {
    name: "MrC Rent A Car",
    category: "Car Rental Website",
    image: "/images/projects/mrc-rentacar.png",
    description:
      "A premium car rental website with a cinematic fleet showcase and a streamlined booking experience.",
    demoUrl: "https://mrcrentacar.space-z.ai/",
  },
  {
    name: "Hamadify Store",
    category: "Shopify E-commerce Project",
    image: "/images/projects/hamadify-store.png",
    description:
      "A Shopify e-commerce store featuring premium comfort products, promotional hero banners, and a polished shopping experience.",
    demoUrl: "https://hamadify.store",
  },
];

export function Projects() {
  const reduced = useReducedMotion();
  const featured = PROJECTS.find((p) => p.featured)!;
  const rest = PROJECTS.filter((p) => !p.featured);

  return (
    <section id="projects" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/4 top-0 -z-10 h-[50vh] w-[50vh] rounded-full bg-teal-700/10 blur-[150px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-14 flex flex-col gap-4">
          <Reveal>
            <div className="flex items-center gap-3">
              <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">04</span>
              <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                Featured Projects
              </span>
            </div>
          </Reveal>
          <AnimatedText
            text="Selected Work & Live Builds."
            as="h2"
            className="font-display max-w-3xl text-4xl uppercase leading-[0.95] text-white sm:text-5xl md:text-6xl"
          />
          <Reveal delay={0.15}>
            <p className="max-w-2xl text-base text-muted-foreground sm:text-lg">
              A collection of live platforms and websites I&apos;ve built — each
              card shows a real screenshot captured from the actual live site,
              with a working Live Demo link.
            </p>
          </Reveal>
        </div>

        {/* featured project */}
        <ProjectCard project={featured} index={0} featured reduced={reduced} />

        {/* grid */}
        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {rest.map((project, i) => (
            <ProjectCard key={project.name} project={project} index={i + 1} reduced={reduced} />
          ))}
        </div>

        {/* CTA strip */}
        <Reveal delay={0.1}>
          <div className="mt-12 flex flex-col items-center justify-between gap-4 rounded-2xl gradient-border p-6 text-center sm:flex-row sm:text-left">
            <div>
              <h3 className="font-display text-xl uppercase text-white sm:text-2xl">
                Have a project in mind?
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Let&apos;s discuss your next build — from concept to launch.
              </p>
            </div>
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
              className="btn-ghost-glow flex shrink-0 items-center gap-2 rounded-full px-6 py-3 font-accent text-sm uppercase tracking-wider"
            >
              Start a Project
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function ProjectCard({
  project,
  index,
  featured = false,
  reduced,
}: {
  project: Project;
  index: number;
  featured?: boolean;
  reduced: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 150, damping: 16 });
  const sry = useSpring(ry, { stiffness: 150, damping: 16 });
  const rotateX = useTransform(sry, [-0.5, 0.5], ["7deg", "-7deg"]);
  const rotateY = useTransform(srx, [-0.5, 0.5], ["-7deg", "7deg"]);

  function onMove(e: MouseEvent<HTMLDivElement>) {
    if (reduced || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    rx.set((e.clientX - (r.left + r.width / 2)) / r.width);
    ry.set((e.clientY - (r.top + r.height / 2)) / r.height);
  }
  function onLeave() {
    rx.set(0);
    ry.set(0);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 48 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 0.7, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      style={{ perspective: 1200 }}
      className={cn(featured && "lg:col-span-3")}
    >
      <motion.div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        style={reduced ? {} : { rotateX, rotateY, transformStyle: "preserve-3d" }}
        className={cn(
          "group relative overflow-hidden rounded-3xl gradient-border neon-border-hover",
          featured ? "flex flex-col lg:flex-row" : "flex flex-col",
        )}
      >
        {/* image */}
        <div
          className={cn(
            "relative overflow-hidden",
            featured ? "aspect-[16/10] lg:aspect-auto lg:w-3/5" : "aspect-[16/10]",
          )}
          style={{ transform: "translateZ(30px)" }}
        >
          <Image
            src={project.image}
            alt={`${project.name} — ${project.category} real website screenshot`}
            fill
            sizes={featured ? "(max-width: 1024px) 100vw, 60vw" : "(max-width: 768px) 100vw, 33vw"}
            className="object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-teal-500/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

          {/* floating category chip */}
          <div className="absolute left-4 top-4 flex items-center gap-1.5 rounded-full glass-strong px-3 py-1.5">
            <Tag className="h-3 w-3 text-teal-300" />
            <span className="font-accent text-[0.6rem] uppercase tracking-widest text-teal-100">
              {project.category}
            </span>
          </div>

          {featured && (
            <div className="absolute right-4 top-4 rounded-full bg-teal-500/90 px-3 py-1 font-accent text-[0.6rem] uppercase tracking-widest text-black">
              Featured
            </div>
          )}
        </div>

        {/* content */}
        <div
          className={cn(
            "relative flex flex-col justify-between gap-6 p-6 sm:p-7",
            featured ? "lg:w-2/5" : "",
          )}
          style={{ transform: "translateZ(20px)" }}
        >
          <div>
            <div className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/70">
              Project {String(index + 1).padStart(2, "0")}
            </div>
            <h3
              className={cn(
                "mt-2 font-display uppercase leading-none text-white",
                featured ? "text-3xl sm:text-4xl" : "text-2xl",
              )}
            >
              {project.name}
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {project.description}
            </p>
          </div>

          {/* Live Demo — real URL, new tab */}
          {project.demoUrl && (
            <a
              href={project.demoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group/btn inline-flex items-center gap-2 self-start rounded-full border border-teal-400/40 bg-teal-500/10 px-5 py-2.5 font-accent text-sm uppercase tracking-wider text-teal-200 transition-all duration-300 hover:border-teal-300 hover:bg-teal-500/20 hover:shadow-[0_0_24px_rgba(45,212,191,0.45)]"
            >
              <ExternalLink className="h-4 w-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
              Live Demo
            </a>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
