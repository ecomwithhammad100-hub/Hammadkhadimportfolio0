"use client";

import { motion } from "framer-motion";
import {
  ArrowUpRight,
  Briefcase,
  LayoutDashboard,
  LayoutTemplate,
  Monitor,
  PenTool,
} from "lucide-react";
import { type ReactNode } from "react";
import { AnimatedText } from "./animated-text";
import { Reveal } from "./reveal";
import { ShopifyMark } from "./shopify-logo";

type Service = {
  num: string;
  title: string;
  icon: ReactNode;
  desc: string;
  tags: string[];
};

const SERVICES: Service[] = [
  {
    num: "01",
    title: "Professional Website Design",
    icon: <Monitor className="h-7 w-7" />,
    desc: "Beautiful, modern, art-directed websites crafted to make a memorable first impression.",
    tags: ["Modern", "Art Direction", "Branding"],
  },
  {
    num: "02",
    title: "UI/UX Design",
    icon: <PenTool className="h-7 w-7" />,
    desc: "User-centred interfaces and design systems focused on clarity, usability, and delight.",
    tags: ["Wireframes", "Design Systems", "Prototyping"],
  },
  {
    num: "03",
    title: "Shopify Store Development",
    icon: <ShopifyMark size={28} />,
    desc: "Complete, conversion-ready Shopify stores built from the ground up — fast and scalable.",
    tags: ["Store Setup", "Apps", "Optimization"],
  },
  {
    num: "04",
    title: "Custom Shopify Themes",
    icon: <ShopifyMark size={28} />,
    desc: "Bespoke Online Store 2.0 themes with custom Liquid sections and editable settings.",
    tags: ["Liquid", "Sections", "OS 2.0"],
  },
  {
    num: "05",
    title: "Business Website Development",
    icon: <Briefcase className="h-7 w-7" />,
    desc: "Professional business websites that establish credibility and a strong digital presence.",
    tags: ["Corporate", "CMS", "SEO"],
  },
  {
    num: "06",
    title: "Landing Page Design",
    icon: <LayoutTemplate className="h-7 w-7" />,
    desc: "High-impact, focused landing pages engineered to capture attention and drive action.",
    tags: ["Conversion", "Animation", "Fast"],
  },
  {
    num: "07",
    title: "Custom Admin Dashboards",
    icon: <LayoutDashboard className="h-7 w-7" />,
    desc: "Tailored admin panels and internal tools with clean data visualisation and controls.",
    tags: ["Dashboards", "Data", "UX"],
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-0 -z-10 h-[50vh] w-[40vh] rounded-full bg-teal-600/10 blur-[150px]" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-14 flex flex-col gap-4">
          <Reveal>
            <div className="flex items-center gap-3">
              <span className="font-accent text-xs tracking-[0.3em] text-teal-400/70">03</span>
              <span className="h-px w-8 bg-gradient-to-r from-teal-400/80 to-transparent" />
              <span className="font-accent text-xs uppercase tracking-[0.3em] text-teal-300/80">
                Services
              </span>
            </div>
          </Reveal>
          <AnimatedText
            text="What I Create for Clients."
            as="h2"
            className="font-display max-w-3xl text-4xl uppercase leading-[0.95] text-white sm:text-5xl md:text-6xl"
          />
          <Reveal delay={0.15}>
            <p className="max-w-2xl text-base text-muted-foreground sm:text-lg">
              From full Shopify stores to focused landing pages and custom
              dashboards — a complete range of design and development services.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => (
            <motion.article
              key={service.num}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10% 0px" }}
              transition={{ duration: 0.6, delay: (i % 3) * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="group relative flex flex-col overflow-hidden rounded-3xl gradient-border p-6 neon-border-hover"
            >
              <span className="pointer-events-none absolute -right-2 -top-6 font-display text-[7rem] leading-none text-white/[0.03] transition-all duration-500 group-hover:text-teal-400/10">
                {service.num}
              </span>

              <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                <div className="absolute -bottom-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-teal-500/15 blur-3xl" />
              </div>

              <div className="relative flex items-center justify-between">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-teal-400/30 bg-teal-500/10 text-teal-300 transition-all duration-500 group-hover:scale-110 group-hover:rotate-3 group-hover:border-teal-300/60 group-hover:shadow-[0_0_24px_rgba(45,212,191,0.5)]">
                  {service.icon}
                </div>
                <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-all duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-teal-300" />
              </div>

              <h3 className="relative mt-6 font-display text-xl uppercase leading-tight text-white">
                {service.title}
              </h3>
              <p className="relative mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                {service.desc}
              </p>

              <div className="relative mt-5 flex flex-wrap gap-2">
                {service.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 font-accent text-[0.6rem] uppercase tracking-widest text-muted-foreground"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
