import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  images: {
    // Serve images directly without the sharp-based optimizer, which is
    // unstable in this dev sandbox and crashes the dev server on large PNGs.
    unoptimized: true,
  },
};

export default nextConfig;
