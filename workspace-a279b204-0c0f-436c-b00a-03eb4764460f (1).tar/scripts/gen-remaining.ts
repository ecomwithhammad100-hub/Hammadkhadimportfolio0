import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";
import path from "path";

const REMAINING = [
  {
    file: "numify.png",
    prompt:
      "Cinematic dark SaaS dashboard UI mockup for a virtual number platform, deep black background with emerald teal gradient glow, glassmorphism panels, virtual phone number management interface, statistics charts with emerald glow, sidebar navigation, neon glowing borders, ultra detailed, 16:10 aspect, premium web app showcase",
  },
  {
    file: "adnexa.png",
    prompt:
      "Cinematic dark digital advertising platform dashboard UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism campaign cards, ad performance charts with emerald glow, campaign management interface, neon glowing borders, analytics graphs, ultra detailed, 16:10 aspect, premium web app showcase",
  },
  {
    file: "channelmart.png",
    prompt:
      "Cinematic dark digital marketplace website UI mockup, deep black background with emerald teal gradient lighting, glassmorphism product listing cards with neon emerald borders, marketplace hero banner, category filters, modern condensed typography, ultra detailed, 16:10 aspect, premium web design showcase",
  },
  {
    file: "mrc-rentacar.png",
    prompt:
      "Cinematic dark car rental website homepage UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism booking card with neon glow, luxury car hero image, search booking form, modern condensed typography, neon glowing buttons, ultra detailed, 16:10 aspect, premium web design showcase",
  },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function main() {
  console.log("init SDK…");
  const zai = await ZAI.create();
  const outDir = "public/images/projects";
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  for (const p of REMAINING) {
    const outPath = path.join(outDir, p.file);
    if (fs.existsSync(outPath)) {
      console.log("skip:", p.file);
      continue;
    }
    let done = false;
    for (let attempt = 1; attempt <= 4 && !done; attempt++) {
      try {
        console.log(`gen ${p.file} (attempt ${attempt})…`);
        const resp = await zai.images.generations.create({
          prompt: p.prompt,
          size: "1344x768",
        });
        const b64 = resp.data?.[0]?.base64;
        if (!b64) throw new Error("no base64");
        fs.writeFileSync(outPath, Buffer.from(b64, "base64"));
        console.log("saved:", p.file, fs.statSync(outPath).size, "bytes");
        done = true;
      } catch (e: any) {
        console.error("fail", p.file, e.message);
        await sleep(8000 * attempt); // backoff
      }
    }
    await sleep(4000); // spacing between items
  }
  console.log("DONE");
}

main().catch((e) => { console.error(e); process.exit(1); });
