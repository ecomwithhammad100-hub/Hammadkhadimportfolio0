import sharp from "sharp";
import fs from "fs";
import path from "path";

async function main() {
  const dir = "public/images/projects";
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".png"));
  for (const f of files) {
    const p = path.join(dir, f);
    const buf = fs.readFileSync(p);
    // re-encode as a true PNG
    const out = await sharp(buf).png({ quality: 90 }).toBuffer();
    fs.writeFileSync(p, out);
    console.log("fixed:", f, out.length, "bytes");
  }
  console.log("DONE");
}
main().catch((e) => { console.error(e); process.exit(1); });
