import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";

async function main() {
  const inPath = "upload/Screenshot (19).png";
  const outPath = "public/images/portrait-new.png";

  const buf = fs.readFileSync(inPath);
  const b64 = buf.toString("base64");
  const dataUrl = `data:image/png;base64,${b64}`;

  console.log("Initializing SDK…");
  const zai = await ZAI.create();

  const prompt =
    "Extract ONLY the young man from this image and preserve him EXACTLY — keep his real face, facial features, skin tone, expression, and IDENTITY identical. CRITICALLY: keep his hairstyle EXACTLY as it is — the thick dark voluminous fringe sweeping across the forehead — do NOT change, trim, or alter the hairstyle in any way, keep it completely natural. Keep his cream/beige patterned traditional vest over the dark shirt exactly. Remove EVERYTHING else completely — all graphic UI elements, floating cards, text labels, icons, charts, badges, buttons, glow blobs, circles, and the entire designed background. Replace all of that with a pure solid deep black background (#000000). Add subtle emerald-teal green rim lighting glowing softly along the edges of his hair, shoulders, and arms to separate him from the black background. Professional cinematic studio portrait cutout on pure black, sharp focus, high detail.";

  console.log("Calling image edit… (864x1152)");
  const resp = await zai.images.generations.edit({
    prompt,
    images: [{ url: dataUrl }],
    size: "864x1152",
  });

  const outB64 = resp.data?.[0]?.base64;
  if (!outB64) {
    console.error("No base64 in response:", JSON.stringify(resp).slice(0, 500));
    process.exit(1);
  }

  fs.writeFileSync(outPath, Buffer.from(outB64, "base64"));
  console.log("Saved:", outPath, fs.statSync(outPath).size, "bytes");
}

main().catch((e) => {
  console.error("FAILED:", e);
  process.exit(1);
});
