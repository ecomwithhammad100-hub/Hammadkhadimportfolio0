import sharp from "sharp";

async function main() {
  const inPath = "public/images/portrait.png";
  const outPath = "public/images/portrait.png";

  const meta = await sharp(inPath).metadata();
  const w = meta.width ?? 864;
  const h = meta.height ?? 1152;

  // Paint a solid black rectangle over the bottom-right watermark area.
  // The "Remo AI" watermark sits roughly in the bottom-right 18% x 6%.
  const boxW = Math.round(w * 0.34);
  const boxH = Math.round(h * 0.07);
  const left = w - boxW - Math.round(w * 0.01);
  const top = h - boxH - Math.round(h * 0.012);

  const overlay = Buffer.from(
    `<svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">
      <rect x="${left}" y="${top}" width="${boxW}" height="${boxH}" fill="#000000"/>
    </svg>`,
  );

  await sharp(inPath)
    .composite([{ input: overlay, blend: "over" }])
    .png()
    .toFile(outPath + ".tmp");

  const fs = await import("fs");
  fs.renameSync(outPath + ".tmp", outPath);
  console.log("Watermark removed. Size:", (await sharp(outPath).metadata()).width, "x", (await sharp(outPath).metadata()).height);
}

main().catch((e) => { console.error(e); process.exit(1); });
