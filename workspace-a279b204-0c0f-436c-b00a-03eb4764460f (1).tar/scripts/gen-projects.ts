import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";
import path from "path";

const PROJECTS = [
  {
    file: "hamadify-store.png",
    prompt:
      "Cinematic dark ecommerce website storefront UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism product cards with neon emerald glow borders, premium online store homepage, product grid, hero banner, modern condensed typography, ultra detailed, 16:10 aspect, professional web design showcase",
  },
  {
    file: "numify.png",
    prompt:
      "Cinematic dark SaaS dashboard UI mockup for a virtual number platform, deep black background with emerald teal gradient glow, glassmorphism panels, virtual phone number management interface, statistics charts with emerald glow, sidebar navigation, neon glowing borders, ultra detailed, 16:10 aspect, premium web app showcase",
  },
  {
    file: "pak-panel.png",
    prompt:
      "Cinematic dark SMM social media marketing panel dashboard UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism cards, order statistics charts glowing emerald, service packages list, sidebar menu, neon glowing buttons, ultra detailed, 16:10 aspect, premium web app showcase",
  },
  {
    file: "apkhub.png",
    prompt:
      "Cinematic dark digital app store marketplace UI mockup, deep black background with emerald teal gradient lighting, glassmorphism app cards with neon borders, app listing grid with download buttons, category navigation, modern condensed headings, ultra detailed, 16:10 aspect, premium web design showcase",
  },
  {
    file: "adnexa.png",
    prompt:
      "Cinematic dark digital advertising platform dashboard UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism campaign cards, ad performance charts with emerald glow, campaign management interface, neon glowing borders, analytics graphs, ultra detailed, 16:10 aspect, premium web app showcase",
  },
  {
    file: "channelmart.png",
    prompt:
      "Cinematic dark digital marketplace website UI mockup, deep black background with emerald teal gradient lighting, glassmorphism product listing cards with neon emerald borders, marketplace hero banner, category filters, modern condensed typography, ultra detailed, 16:10 aspect, premium web design showcase",
  },
  {
    file: "mrc-rentacar.png",
    prompt:
      "Cinematic dark car rental website homepage UI mockup, deep black background with emerald and teal gradient lighting, glassmorphism booking card with neon glow, luxury car hero image, search booking form, modern condensed typography, neon glowing buttons, ultra detailed, 16:10 aspect, premium web design showcase",
  },
];

async function genOne(zai: any, p: { file: string; prompt: string }) {
  const outDir = "public/images/projects";
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, p.file);
  if (fs.existsSync(outPath)) {
    console.log("skip (exists):", p.file);
    return;
  }
  try {
    const resp = await zai.images.generations.create({
      prompt: p.prompt,
      size: "1344x768",
    });
    const b64 = resp.data?.[0]?.base64;
    if (!b64) throw new Error("no base64");
    fs.writeFileSync(outPath, Buffer.from(b64, "base64"));
    console.log("saved:", p.file, fs.statSync(outPath).size, "bytes");
  } catch (e: any) {
    console.error("FAIL", p.file, e.message);
  }
}

async function main() {
  console.log("init SDK…");
  const zai = await ZAI.create();
  // run 3 at a time to be gentle
  const queue = [...PROJECTS];
  const workers = [0, 1, 2];
  await Promise.all(
    workers.map(async () => {
      while (queue.length) {
        await genOne(zai, queue.shift()!);
      }
    }),
  );
  console.log("ALL DONE");
}

main().catch((e) => { console.error(e); process.exit(1); });
