#!/bin/bash
# Watchdog: keep the Next.js dev server alive on port 3000.
cd /home/z/my-project
while true; do
  if ! pgrep -f "next dev -p 3000" > /dev/null 2>&1; then
    echo "[$(date +%T)] dev server down — restarting…" >> /tmp/watchdog.log
    bun run dev > /dev/null 2>&1 &
    sleep 8
  fi
  sleep 5
done
