import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";

async function main() {
  const inPath = "public/images/portrait-original.jpg";
  const outPath = "public/images/portrait.png";

  const buf = fs.readFileSync(inPath);
  const b64 = buf.toString("base64");
  const dataUrl = `data:image/jpeg;base64,${b64}`;

  console.log("Initializing SDK…");
  const zai = await ZAI.create();

  const prompt =
    "Keep this person EXACTLY the same — preserve his real face, facial features, hairstyle, skin tone, eyes, expression, white shalwar kameez kurta clothing, body proportions and standing pose precisely. Do NOT change his identity. Remove the entire outdoor background completely (sky, hills, trees, fence, pole, ruins, all scenery) and replace it with a pure solid deep black background (#000000). Add subtle emerald-teal green rim lighting glowing along the edges and shoulders of the subject. Professional cinematic studio portrait cutout on pure black, sharp focus.";

  console.log("Calling image edit…", { size: "864x1152" });
  const resp = await zai.images.generations.edit({
    prompt,
    images: [{ url: dataUrl }],
    size: "864x1152",
  });

  const outB64 = resp.data?.[0]?.base64;
  if (!outB64) {
    console.error("No base64 in response:", JSON.stringify(resp).slice(0, 500));
    process.exit(1);
  }

  fs.writeFileSync(outPath, Buffer.from(outB64, "base64"));
  console.log("Saved:", outPath, fs.statSync(outPath).size, "bytes");
}

main().catch((e) => {
  console.error("FAILED:", e);
  process.exit(1);
});
