import sharp from "sharp";
import fs from "fs";

async function main() {
  const dir = "public/images/projects";
  const targets = [
    "numify.png",
    "pak-panel.png",
    "apkhub.png",
    "adnexa.png",
    "mrc-rentacar.png",
    "hamadify-store.png",
  ];
  const W = 1600;
  const H = 1000; // 16:10

  for (const f of targets) {
    const p = `${dir}/${f}`;
    if (!fs.existsSync(p)) {
      console.log("missing:", f);
      continue;
    }
    const tmp = p + ".tmp.png";
    await sharp(p)
      .resize(W, H, { fit: "cover", position: "top" })
      .png({ quality: 80, compressionLevel: 9 })
      .toFile(tmp);
    fs.renameSync(tmp, p);
    console.log("optimized:", f, fs.statSync(p).size, "bytes");
  }
  console.log("DONE");
}
main().catch((e) => { console.error(e); process.exit(1); });
