#!/bin/bash
# Double-fork daemon: fully detaches the dev server from any controlling
# terminal/session so it survives shell exits.
cd /home/z/my-project

# Fork once
( (
  # grandchild — new session, no controlling terminal
  exec setsid bun run dev >> /home/z/my-project/dev.log 2>&1
) & )

# parent exits immediately
exit 0
