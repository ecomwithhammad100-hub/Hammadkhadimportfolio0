/* ==========================================================================
   Hammad Khadim — theme.js (vanilla, no jQuery)
   Features:
     • Waterfall name reveal (per-letter fall + spring ease + blur trail +
       teal glow that fades on settle + soft impact pulse)
     • Scroll progress bar
     • Reveal-on-scroll (IntersectionObserver)
     • Navbar scroll-compact + mobile toggle
     • Parallax (mouse-move on [data-parallax])
     • Magnetic buttons ([data-magnetic])
     • 3D tilt ([data-tilt])
     • Animated counters ([data-counter] — single integers with optional
       + or %; ranges/text stay static)
     • Scroll-spy nav
     • Back-to-top
   No loading screen / preloader — the site opens immediately.
   Respects prefers-reduced-motion throughout.
   ========================================================================== */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function raf(fn) {
    if (window.requestAnimationFrame) window.requestAnimationFrame(fn);
    else window.setTimeout(fn, 16);
  }

  /* ---------- Waterfall name reveal ---------- */
  function initWaterfall() {
    var letters = document.querySelectorAll('[data-waterfall]');
    if (!letters.length) return;

    if (reduceMotion) {
      letters.forEach(function (el) {
        el.style.opacity = '1';
        el.style.transform = 'none';
        el.style.filter = 'none';
      });
      return;
    }

    // Initial falling state: above the viewport, transparent, blurred, rotated,
    // with a teal glow text-shadow that will fade as the letter settles.
    letters.forEach(function (el, i) {
      var rot = ((i % 2 ? 1 : -1) * (5 + (i % 4) * 2.5));
      var drop = 240 + (i % 5) * 28;
      el.style.opacity = '0';
      el.style.transform = 'translateY(-' + drop + 'px) rotate(' + rot + 'deg)';
      el.style.filter = 'blur(10px)';
      el.style.textShadow =
        '0 0 18px rgba(46,230,200,0.9), 0 0 36px rgba(45,212,191,0.6)';
      el.style.transition =
        'transform 900ms cubic-bezier(0.34, 1.56, 0.64, 1),' +
        'opacity 700ms cubic-bezier(0.22, 1, 0.36, 1),' +
        'filter 700ms cubic-bezier(0.22, 1, 0.36, 1),' +
        'text-shadow 900ms ease-out';
      el.style.transitionDelay = (i * 70) + 'ms';
      el.style.willChange = 'transform, opacity, filter';
    });

    // Trigger settle on the next frame so the browser registers the
    // initial state before transitioning.
    raf(function () {
      raf(function () {
        letters.forEach(function (el) {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0) rotate(0deg)';
          el.style.filter = 'blur(0px)';
          el.style.textShadow = '0 0 0 rgba(46,230,200,0)';
        });

        // Reveal the teal underline swoosh beneath the name.
        var swooshes = document.querySelectorAll('[data-swoosh]');
        swooshes.forEach(function (el) { el.classList.add('is-settled'); });

        // Soft impact pulse once each letter has settled.
        letters.forEach(function (el, i) {
          var settleAt = i * 70 + 880;
          window.setTimeout(function () {
            el.classList.add('waterfall-impact');
            window.setTimeout(function () {
              el.classList.remove('waterfall-impact');
            }, 520);
          }, settleAt);
        });
      });
    });
  }

  /* ---------- Scroll progress ---------- */
  function initScrollProgress() {
    var bar = document.querySelector('[data-scroll-progress]');
    if (!bar) return;
    if (reduceMotion) { bar.style.display = 'none'; return; }
    function update() {
      var h = document.documentElement;
      var scrolled = h.scrollTop || document.body.scrollTop;
      var height = h.scrollHeight - h.clientHeight;
      var pct = height > 0 ? (scrolled / height) * 100 : 0;
      bar.style.width = pct + '%';
    }
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });
  }

  /* ---------- Navbar scrolled state ---------- */
  function initNavScroll() {
    var header = document.querySelector('[data-header]');
    if (!header) return;
    function onScroll() {
      if (window.scrollY > 40) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Mobile nav toggle ---------- */
  function initMobileNav() {
    var toggle = document.querySelector('[data-nav-toggle]');
    var menu = document.querySelector('[data-mobile-nav]');
    if (!toggle || !menu) return;
    function close() {
      toggle.setAttribute('aria-expanded', 'false');
      menu.classList.remove('is-open');
      document.body.style.overflow = '';
    }
    function open() {
      toggle.setAttribute('aria-expanded', 'true');
      menu.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    }
    toggle.addEventListener('click', function () {
      if (toggle.getAttribute('aria-expanded') === 'true') close();
      else open();
    });
    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', close);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth > 880) close();
    });
  }

  /* ---------- Reveal on scroll ---------- */
  function initReveal() {
    var items = document.querySelectorAll('.reveal');
    if (!items.length) return;
    if (reduceMotion) {
      items.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    items.forEach(function (el) { io.observe(el); });
  }

  /* ---------- Rotating titles (optional, used if [data-rotating-titles] present) ---------- */
  function initRotatingTitles() {
    var rotator = document.querySelector('[data-rotating-titles]');
    if (!rotator || reduceMotion) return;
    var items = Array.prototype.slice.call(rotator.querySelectorAll('.rotator__item'));
    if (items.length < 2) return;
    var idx = 0;
    items[0].classList.add('is-visible');
    setInterval(function () {
      items[idx].classList.remove('is-visible');
      idx = (idx + 1) % items.length;
      items[idx].classList.add('is-visible');
    }, 2600);
  }

  /* ---------- Skill tier accent bar fill ---------- */
  function initTierBars() {
    var bars = document.querySelectorAll('[data-tier-fill]');
    if (!bars.length) return;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      bars.forEach(function (el) { el.classList.add('is-filled'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-filled');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });
    bars.forEach(function (el) { io.observe(el); });
  }

  /* ---------- Parallax (mouse move) ---------- */
  function initParallax() {
    if (reduceMotion) return;
    var nodes = document.querySelectorAll('[data-parallax]');
    if (!nodes.length) return;
    var hero = document.querySelector('[data-hero]') || document.body;
    var strength = 0.02;
    hero.addEventListener('mousemove', function (e) {
      var rect = hero.getBoundingClientRect();
      var cx = (e.clientX - rect.left) / rect.width - 0.5;
      var cy = (e.clientY - rect.top) / rect.height - 0.5;
      nodes.forEach(function (n) {
        var depth = parseFloat(n.getAttribute('data-parallax')) || 1;
        n.style.transform = 'translate3d(' + (-cx * 30 * depth * strength * 10) + 'px,' + (-cy * 30 * depth * strength * 10) + 'px, 0)';
      });
    });
  }

  /* ---------- Magnetic buttons ---------- */
  function initMagnetic() {
    if (reduceMotion) return;
    var nodes = document.querySelectorAll('[data-magnetic]');
    if (!nodes.length) return;
    nodes.forEach(function (el) {
      var strength = 0.35;
      el.addEventListener('mousemove', function (e) {
        var rect = el.getBoundingClientRect();
        var x = e.clientX - rect.left - rect.width / 2;
        var y = e.clientY - rect.top - rect.height / 2;
        el.style.transform = 'translate(' + (x * strength) + 'px,' + (y * strength) + 'px)';
      });
      el.addEventListener('mouseleave', function () {
        el.style.transform = '';
      });
    });
  }

  /* ---------- 3D tilt on cards ---------- */
  function initTilt() {
    if (reduceMotion) return;
    var cards = document.querySelectorAll('[data-tilt]');
    if (!cards.length) return;
    cards.forEach(function (card) {
      var max = 10;
      card.addEventListener('mousemove', function (e) {
        var rect = card.getBoundingClientRect();
        var px = (e.clientX - rect.left) / rect.width;
        var py = (e.clientY - rect.top) / rect.height;
        var rx = (0.5 - py) * max;
        var ry = (px - 0.5) * max;
        card.style.transform = 'perspective(900px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg) translateY(-6px)';
      });
      card.addEventListener('mouseleave', function () {
        card.style.transform = '';
      });
    });
  }

  /* ---------- Animated counters ---------- */
  function initCounters() {
    var nodes = document.querySelectorAll('[data-counter]');
    if (!nodes.length) return;
    function animate(el, target) {
      var suffix = el.getAttribute('data-suffix') || '';
      var prefix = el.getAttribute('data-prefix') || '';
      var dur = 1600;
      var start = null;
      function step(ts) {
        if (!start) start = ts;
        var p = Math.min((ts - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = Math.round(eased * target);
        el.textContent = prefix + val + suffix;
        if (p < 1) requestAnimationFrame(step);
        else el.textContent = prefix + target + suffix;
      }
      requestAnimationFrame(step);
    }
    if (reduceMotion || !('IntersectionObserver' in window)) {
      nodes.forEach(function (el) {
        var target = parseInt(el.getAttribute('data-counter'), 10) || 0;
        var suffix = el.getAttribute('data-suffix') || '';
        var prefix = el.getAttribute('data-prefix') || '';
        el.textContent = prefix + target + suffix;
      });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var target = parseInt(entry.target.getAttribute('data-counter'), 10) || 0;
          animate(entry.target, target);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    nodes.forEach(function (el) { io.observe(el); });
  }

  /* ---------- Scroll-spy (active nav link) ---------- */
  function initScrollSpy() {
    var links = document.querySelectorAll('[data-nav-link]');
    if (!links.length) return;
    var sections = [];
    links.forEach(function (link) {
      var href = link.getAttribute('href') || '';
      if (href.indexOf('#') === 0 && href.length > 1) {
        var sec = document.querySelector(href);
        if (sec) sections.push({ link: link, sec: sec });
      }
    });
    if (!sections.length) return;
    function onScroll() {
      var pos = window.scrollY + window.innerHeight * 0.3;
      var current = null;
      sections.forEach(function (s) {
        if (s.sec.offsetTop <= pos) current = s;
      });
      links.forEach(function (l) { l.classList.remove('is-active'); });
      if (current) current.link.classList.add('is-active');
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Back to top ---------- */
  function initBackToTop() {
    var btn = document.querySelector('[data-back-to-top]');
    if (!btn) return;
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  }

  /* ---------- Boot ---------- */
  ready(function () {
    initWaterfall();
    initScrollProgress();
    initNavScroll();
    initMobileNav();
    initReveal();
    initRotatingTitles();
    initTierBars();
    initParallax();
    initMagnetic();
    initTilt();
    initCounters();
    initScrollSpy();
    initBackToTop();
  });

  // Re-run on Shopify customizer events
  if (window.Shopify && window.Shopify.designMode) {
    document.addEventListener('shopify:section:load', function () {
      initWaterfall();
      initReveal();
      initRotatingTitles();
      initTierBars();
      initCounters();
    });
  }
})();
