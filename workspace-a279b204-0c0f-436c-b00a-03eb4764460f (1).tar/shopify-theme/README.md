# Hammad Khadim — Portfolio Shopify Theme

A production-ready Shopify Online Store 2.0 theme built for a **personal
portfolio website** (not an ecommerce store). Designed for **Hammad Khadim** —
**Web Designer & Shopify Expert** — with a cinematic dark aesthetic: near-black
background, turquoise/teal gradient lighting, large condensed typography,
glassmorphism, neon glowing borders, and a **waterfall name reveal** animation
in the hero.

> ⚠️ This theme deliberately disables Shopify's commerce features (cart,
> checkout, products, collections, customer accounts, search). It uses
> Shopify purely as a hosting + CMS + theme-customizer platform for a
> portfolio.

---

## 1. What's inside

```
shopify-theme/
├── assets/
│   ├── theme.css                  Cinematic dark + turquoise/teal styles
│   ├── theme.js                   Vanilla JS (waterfall name reveal + animations)
│   ├── portrait.png               Default portrait (used by Hero + About)
│   └── projects/
│       ├── numify.png             Real screenshot — numify.space-z.ai
│       ├── pak-panel.png          Real screenshot — pakpanel.space-z.ai
│       ├── apkhub.png             Real screenshot — apkhub1.space-z.ai
│       ├── adnexa.png             Real screenshot — adnexa.space-z.ai
│       ├── mrc-rentacar.png       Real screenshot — mrcrentacar.space-z.ai
│       └── hamadify-store.png     Real screenshot — hamadify.store
├── config/
│   ├── settings_schema.json       Theme settings (colors, fonts, contact, social)
│   └── settings_data.json         Default cinematic values + theme preset
├── layout/
│   └── theme.liquid               Full HTML doc; loads fonts + assets; NO loader
├── locales/
│   └── en.default.json            Translation strings
├── sections/
│   ├── announcement-bar.liquid
│   ├── header.liquid              Text name nav (no logo), link_list menu
│   ├── hero.liquid                Waterfall name + portrait + bottom stats bar
│   ├── about.liquid               Split-screen, focus list, pillars, quote
│   ├── skills.liquid              11 skills, 3D tilt, tier accent bar, marquee
│   ├── services.liquid            7 services, ghost number, tags
│   ├── projects.liquid            6 projects, real screenshots + live demo URLs
│   ├── stats.liquid               4 stat cards + achievement strip
│   ├── contact.liquid             CTAs + project inquiry panel
│   └── footer.liquid              Text name, nav, socials, back-to-top
├── snippets/
│   ├── section-heading.liquid     Reusable eyebrow + title + description
│   ├── button.liquid              Button with glow / ghost variants
│   ├── icon.liquid                Inline SVG icon set
│   ├── magnetic-button.liquid     Magnetic-hover button wrapper
│   └── project-card.liquid        Reusable project card with Live Demo button
└── templates/
    ├── index.json                 Homepage composition (all sections + defaults)
    ├── page.liquid                Minimal page template
    ├── page.contact.liquid        Alternate contact page
    ├── product.liquid             → redirects home (commerce disabled)
    ├── collection.liquid          → redirects home
    ├── cart.liquid                → redirects home
    ├── blog.liquid                → redirects home
    ├── article.liquid             → redirects home
    ├── list-collections.liquid    → redirects home
    ├── search.liquid              → redirects home
    ├── 404.liquid                 Branded 404 with link home
    ├── password.liquid            Branded password hold screen
    ├── gift_card.liquid           Minimal branded
    └── customers/                 → all redirect home
```

---

## 2. Install the theme

### Step 1 — Zip the theme folder

The `shopify-theme/` folder must be zipped so that `assets/`, `config/`,
`layout/`, `locales/`, `sections/`, `snippets/`, and `templates/` are at the
**top level** of the zip (not nested inside another folder).

On macOS / Linux:
```bash
cd /home/z/my-project
zip -r hammad-khadim-theme.zip shopify-theme -x "*.DS_Store"
```
> If you zip the folder from Finder/Explorer by right-clicking, make sure the
> zip's root contains `layout/`, `config/`, etc. directly.

### Step 2 — Upload to Shopify

1. Log in to **Shopify Admin**.
2. Go to **Online Store → Themes**.
3. Scroll to **Theme library** and click **Add theme → Upload theme**.
4. Choose `hammad-khadim-theme.zip` and click **Upload**.
5. Once uploaded, click **Publish** (or keep it unpublished and click
   **Customize** to preview first).

### Step 3 — Set the homepage

The homepage is `templates/index.json` and is already composed with all
sections and default content. After publishing:

1. Go to **Online Store → Themes → Customize**.
2. At the top of the customizer, ensure the page selector is set to
   **Home page**.
3. You should see the full portfolio flow: Announcement → Header → Hero →
   About → Skills → Services → Projects → Experience → Contact → Footer.

### Step 4 — Set up the navigation menu (optional)

The Header uses a **link_list** setting (default `main-menu`). If your
`main-menu` link list is empty or not set up, the theme falls back to the
default anchor links: Home · About · Skills · Services · Projects · Contact.

To use your own menu:
1. Go to **Online Store → Navigation → Main menu**.
2. Add links pointing to `/#home`, `/#about`, `/#skills`, `/#services`,
   `/#projects`, `/#contact`.

---

## 3. Waterfall name animation

The hero opens with a **waterfall name reveal**: the letters of "HAMMAD" and
"KHADIM" fall from the top of the screen in staggered sequences (~70ms apart)
with gravity-inspired spring easing (a cubic-bezier that overshoots
slightly), a turquoise blur trail, and a teal glow text-shadow that fades as
each letter settles. Each letter ends with a soft impact pulse. A teal
underline swoosh draws in beneath "KHADIM" once the letters settle.

Implementation:
- `sections/hero.liquid` splits `name_line_1` and `name_line_2` into
  per-letter `<span class="hero__name-char" data-waterfall>` elements.
- `assets/theme.js` → `initWaterfall()` selects every `[data-waterfall]`,
  sets the initial falling state (translateY, opacity 0, blur(10px), rotate,
  teal text-shadow), then on the next animation frame transitions each letter
  to its settled state with a staggered `transition-delay`.
- After each letter settles, a `.waterfall-impact` class is briefly applied
  to trigger a soft pulse keyframe.
- `[data-swoosh]` (the underline beneath "KHADIM") gets `.is-settled` at the
  same time so it draws in with a spring ease.

**Accessibility:** `prefers-reduced-motion` is fully respected — when reduced
motion is requested, letters simply appear in place (no fall, no blur, no
glow, no impact pulse), and the swoosh is shown statically. There is **no
loading screen / preloader** — the site opens immediately and navigation +
content remain accessible from the first paint.

---

## 4. Real project screenshots & live demo URLs

Real screenshots captured from live websites are included in
`assets/projects/` and are wired up as defaults in `templates/index.json` so
the **Projects section works out of the box** — no setup required.

| # | Project | Category | Screenshot | Live demo URL |
|---|---|---|---|---|
| 1 | Numify | Virtual Number Platform | `projects/numify.png` | `https://numify.space-z.ai/#/home` |
| 2 | Pak Panel | SMM Panel Platform | `projects/pak-panel.png` | `https://pakpanel.space-z.ai` |
| 3 | APKHub | Digital App Platform | `projects/apkhub.png` | `https://apkhub1.space-z.ai/#/` |
| 4 | Adnexa | Digital Advertising Platform | `projects/adnexa.png` | `https://adnexa.space-z.ai/#/` |
| 5 | MrC Rent A Car | Car Rental Website | `projects/mrc-rentacar.png` | `https://mrcrentacar.space-z.ai/` |
| 6 | Hamadify Store | Shopify E-commerce Project | `projects/hamadify-store.png` | `https://hamadify.store` |

> Note: "Hamadify Store" is a **client project name** (a real Shopify store),
> not personal branding for this theme.

The first project (Numify) is **featured** — it spans the full grid width with
a wide 21:9 screenshot. The rest appear in a 3-column grid.

### How the Live Demo button works

Each project block has two settings:
- **Live demo URL** (`demo_url`, type `url`) — the real site URL.
- **Show Live Demo button** (`show_demo_button`, checkbox, default `true`).

The "LIVE DEMO ↗" button is rendered in `snippets/project-card.liquid`
**only when `show_demo_button` is true AND `demo_url` is not blank**. The
button always opens in a new tab with `target="_blank" rel="noopener
noreferrer"`. When the URL is blank or the toggle is off, **no button is
rendered** — the theme never uses a fake or placeholder URL.

### Editing a project

1. In the customizer, click the **Projects** section, then click a project
   block.
2. Edit the **Project name**, **Category**, **Description**, **Screenshot**
   (image picker), **Screenshot asset path (fallback)**, **Live demo URL**,
   **Show Live Demo button**, and **Featured** toggle.
3. To replace a screenshot, either:
   - Upload a new image via the **Project screenshot** image picker, **or**
   - Replace the file at `assets/projects/<name>.png` in the theme code and
     keep the **Screenshot asset path (fallback)** pointing at it
     (e.g. `projects/numify.png`).

When no image is selected via the picker, the card falls back to the theme
asset at the **Screenshot asset path** so screenshots always show on first
install.

---

## 5. Replacing the portrait

The Hero and About sections both default to `assets/portrait.png` when no
image is selected via their image pickers.

1. In the customizer, click the **Hero** (or **About**) section.
2. Use the **Portrait image** (or **About image**) picker to upload or select
   a file from your Shopify Files library.
3. To replace the default asset directly, swap the file at
   `assets/portrait.png` in the theme code.
4. Recommended size: **800×1000** (4:5).

---

## 6. Updating contact details and social links

### Contact details

Go to **Theme settings (gear icon) → Contact details** to set:

- **Contact email** — used by the Email button, contact panel, and footer.
- **WhatsApp number** — digits only, including country code (e.g.
  `923001234567`). Used to build the `wa.me/<number>?text=<message>` link.
- **WhatsApp display number** — what's shown in the contact panel
  (e.g. `+92 300 1234567`).
- **Default WhatsApp message** — pre-fills the WhatsApp chat.
- **Location** — shown in the contact panel.
- **Response time** — shown in the contact panel.

The **Contact section** itself also has these fields (they override the theme
settings when filled in). Defaults ship with: WhatsApp `+92 300 1234567`,
email `hello@hammadkhadim.com`, location `Pakistan`.

### Social links

Go to **Theme settings → Social links** to set profile URLs:
Instagram, LinkedIn, GitHub, Facebook, Twitter/X, YouTube, Behance, Dribbble.
Empty fields automatically hide their icons in the footer and contact panel.

---

## 7. How commerce is disabled (and why)

This is a **portfolio hosted on Shopify**, not a store. The following
Shopify-native commerce features are intentionally removed or redirected:

| Feature | Status in this theme |
|---|---|
| Cart | Disabled — `cart.liquid` redirects to `/` |
| Add-to-cart buttons | Not present anywhere |
| Checkout | No path leads to checkout |
| Customer accounts | Disabled — all `customers/*` templates redirect to `/` |
| Product pages | `product.liquid` redirects to `/` |
| Collection pages | `collection.liquid` + `list-collections.liquid` redirect to `/` |
| Blog / articles | `blog.liquid` + `article.liquid` redirect to `/` |
| Storefront search | `search.liquid` redirects to `/` (defaults to product search) |
| Gift cards | `gift_card.liquid` is minimal/branded |

Each redirect template includes a Liquid comment explaining why, plus a
short inline `<script>window.location.replace('/')</script>` so visitors are
sent home immediately even if a stray link points to a commerce URL.

To harden this further (optional):
- In **Settings → Customer accounts**, set to "Don't show customer accounts".
- In **Settings → Checkout**, no action required (no cart = no checkout).
- Remove default link lists that reference collections/products in
  **Online Store → Navigation** if any remain.

---

## 8. Motion & accessibility

All animations are **vanilla JS** (no jQuery). Features:
- **Waterfall name reveal** (per-letter fall, spring easing, blur trail, teal
  glow, impact pulse).
- Scroll progress bar.
- Reveal-on-scroll (IntersectionObserver).
- Navbar scroll-compact + mobile toggle.
- Mouse parallax on `[data-parallax]` elements.
- Magnetic buttons (`[data-magnetic]`).
- 3D tilt on project and skill cards (`[data-tilt]`).
- Skill tier accent bar fill on scroll-in (`[data-tier-fill]`).
- Animated counters (`[data-counter]` — single integers with optional `+` or
  `%`; ranges/text stay static).
- Scroll-spy nav.

`prefers-reduced-motion` is respected throughout: the waterfall letters just
fade in, all animations are disabled, `.reveal` elements show immediately,
and the scroll progress bar is hidden. Color contrast meets WCAG AA for body
text on the dark background. All interactive elements are keyboard-reachable;
the mobile nav closes on `Escape`.

---

## 9. Fonts

Loaded via Google Fonts `<link>` in `layout/theme.liquid`:

- **Anton** — display headings (override via Theme settings → Typography).
- **Inter** — body copy.
- **Space Grotesk** — eyebrows, labels, buttons.

The Theme settings font pickers swap these for Oswald / Bebas Neue / Manrope
/ Rubik / Sora / DM Sans / JetBrains Mono as desired.

---

## 10. Default content shipped

The homepage ships with sensible defaults so it looks complete on first
install:

- **Hero** — waterfall name "HAMMAD" / "KHADIM", title "WEB DESIGNER &
  SHOPIFY EXPERT", the new tagline, 3 floating glass skill cards (Shopify,
  `</>` Development, Growth), and a 4-segment bottom stats bar.
- **About** — "THE PERSON BEHIND THE PIXELS.", 4 focus items, 3 pillar
  cards (Design / Development / Experience), and a quote.
- **Skills** — 11 skill cards (UI/UX Design, Website Design, Shopify
  Development, Shopify Liquid, HTML5, CSS3, JavaScript, Responsive Design,
  Landing Page Design, Custom Website Development, Admin Dashboard Design)
  with tier labels (Expert / Advanced) and decorative tier accent bars,
  plus a marquee strip of all skill names.
- **Services** — 7 service cards with tags.
- **Projects** — 6 real projects with real screenshots and live demo URLs
  (see §4).
- **Experience (Stats)** — 4 stat cards (8–10 local projects, 6+ live
  platforms [count-up], Shopify + Web development, 100% independent
  [count-up]) + a 4-item achievement strip.
- **Contact** — WhatsApp / Email Me / View My Work CTAs + project inquiry
  panel + social links.
- **Footer** — text name "HAMMAD KHADIM" + "Web Designer & Shopify Expert"
  subtitle, nav, socials, back-to-top, copyright.

No testimonials, revenue figures, or fabricated metrics are included.

---

## 11. Troubleshooting

- **Homepage looks empty** — confirm the published theme is this one and that
  the customizer page selector is on "Home page". Re-check `templates/index.json`.
- **Waterfall animation doesn't play** — it only runs on the hero. If your
  OS or browser has "reduce motion" enabled, letters will simply fade in.
- **Project screenshot missing** — confirm the file exists at
  `assets/projects/<name>.png` and the block's **Screenshot asset path
  (fallback)** matches it. Or upload an image via the picker.
- **Live Demo button hidden** — the button only shows when **Show Live Demo
  button** is on AND a **Live demo URL** is set. Leave either blank to hide
  it.
- **WhatsApp button doesn't open** — ensure the WhatsApp number has the
  country code and digits only (no `+`, spaces, or dashes).
- **Fonts not loading** — Google Fonts is loaded via `<link>` in
  `layout/theme.liquid`. If your store blocks external requests, switch the
  font pickers to a system stack or self-host fonts in `assets/`.

---

## 12. License

Built for Hammad Khadim. Edit freely for the Hammad Khadim portfolio.
